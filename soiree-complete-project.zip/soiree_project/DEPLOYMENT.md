# Deployment Guide

This guide covers deploying Soirée to production environments.

## Deployment Checklist

- [ ] Update database credentials
- [ ] Set up environment variables
- [ ] Configure production database
- [ ] Set up backup strategy
- [ ] Configure SSL/HTTPS
- [ ] Set up monitoring
- [ ] Configure logging
- [ ] Set resource limits
- [ ] Test all functionality
- [ ] Set up CI/CD (optional)

## Deployment Options

### Option 1: Streamlit Cloud (Easiest)

1. Push your code to GitHub
2. Go to [share.streamlit.io](https://share.streamlit.io)
3. Connect your GitHub repository
4. Configure secrets for database connection
5. Deploy!

**Secrets Configuration:**
```toml
# .streamlit/secrets.toml
[database]
dbname = "your_db"
user = "your_user"
password = "your_password"
host = "your_host"
port = "5432"
```

**Update project.py to use secrets:**
```python
import streamlit as st

DB_CONFIG = {
    'dbname': st.secrets["database"]["dbname"],
    'user': st.secrets["database"]["user"],
    'password': st.secrets["database"]["password"],
    'host': st.secrets["database"]["host"],
    'port': st.secrets["database"]["port"]
}
```

### Option 2: Heroku

1. Create a Heroku account
2. Install Heroku CLI
3. Create files:

**Procfile:**
```
web: sh setup.sh && streamlit run project.py
```

**setup.sh:**
```bash
mkdir -p ~/.streamlit/

echo "\
[server]\n\
headless = true\n\
port = $PORT\n\
enableCORS = false\n\
\n\
" > ~/.streamlit/config.toml
```

**runtime.txt:**
```
python-3.11.0
```

4. Deploy:
```bash
heroku create your-app-name
heroku addons:create heroku-postgresql:mini
git push heroku main
```

### Option 3: AWS EC2

1. **Launch EC2 Instance**
   - Ubuntu 22.04 LTS
   - t2.small or larger
   - Open port 8501

2. **Install Dependencies**
```bash
sudo apt update
sudo apt install python3-pip postgresql postgresql-contrib
```

3. **Set Up Database**
```bash
sudo -u postgres createdb soiree_dtb
sudo -u postgres psql soiree_dtb < schema.sql
sudo -u postgres psql soiree_dtb < load.sql
```

4. **Deploy Application**
```bash
git clone your-repo
cd soiree
pip3 install -r requirements.txt
```

5. **Run with systemd**

Create `/etc/systemd/system/soiree.service`:
```ini
[Unit]
Description=Soiree Application
After=network.target

[Service]
User=ubuntu
WorkingDirectory=/home/ubuntu/soiree
ExecStart=/usr/bin/python3 -m streamlit run project.py
Restart=always

[Install]
WantedBy=multi-user.target
```

Start service:
```bash
sudo systemctl enable soiree
sudo systemctl start soiree
```

6. **Set Up Nginx (Optional)**
```nginx
server {
    listen 80;
    server_name your-domain.com;
    
    location / {
        proxy_pass http://localhost:8501;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }
}
```

### Option 4: Docker

**Dockerfile:**
```dockerfile
FROM python:3.11-slim

WORKDIR /app

RUN apt-get update && apt-get install -y \
    postgresql-client \
    && rm -rf /var/lib/apt/lists/*

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 8501

CMD ["streamlit", "run", "project.py", "--server.port=8501", "--server.address=0.0.0.0"]
```

**docker-compose.yml:**
```yaml
version: '3.8'

services:
  db:
    image: postgres:14
    environment:
      POSTGRES_DB: soiree_dtb
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./schema.sql:/docker-entrypoint-initdb.d/1-schema.sql
      - ./load.sql:/docker-entrypoint-initdb.d/2-load.sql
    ports:
      - "5432:5432"

  app:
    build: .
    ports:
      - "8501:8501"
    depends_on:
      - db
    environment:
      DB_HOST: db
      DB_NAME: soiree_dtb
      DB_USER: postgres
      DB_PASSWORD: postgres

volumes:
  postgres_data:
```

Deploy:
```bash
docker-compose up -d
```

## Environment Variables

Use environment variables for sensitive data:

**.env file:**
```
DB_NAME=soiree_dtb
DB_USER=postgres
DB_PASSWORD=secure_password_here
DB_HOST=localhost
DB_PORT=5432
```

**Update project.py:**
```python
import os
from dotenv import load_dotenv

load_dotenv()

DB_CONFIG = {
    'dbname': os.getenv('DB_NAME'),
    'user': os.getenv('DB_USER'),
    'password': os.getenv('DB_PASSWORD'),
    'host': os.getenv('DB_HOST'),
    'port': os.getenv('DB_PORT', '5432')
}
```

Add to requirements.txt:
```
python-dotenv>=1.0.0
```

## Database Backup

### Automated Backup Script

**backup.sh:**
```bash
#!/bin/bash
BACKUP_DIR="/backups"
DATE=$(date +%Y%m%d_%H%M%S)
FILENAME="soiree_backup_$DATE.sql"

pg_dump -U postgres soiree_dtb > "$BACKUP_DIR/$FILENAME"
gzip "$BACKUP_DIR/$FILENAME"

# Keep only last 7 days
find $BACKUP_DIR -name "soiree_backup_*.sql.gz" -mtime +7 -delete
```

**Cron job (daily at 2 AM):**
```bash
0 2 * * * /path/to/backup.sh
```

## Monitoring

### Health Check Endpoint

Add to project.py:
```python
@st.cache_data(ttl=60)
def check_database_health():
    try:
        conn = get_connection()
        if conn:
            conn.close()
            return True
    except:
        return False
    return False
```

### Logging

Configure logging:
```python
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('soiree.log'),
        logging.StreamHandler()
    ]
)
```

## Security Best Practices

1. **Use HTTPS** - Always use SSL/TLS in production
2. **Secure Database** - Use strong passwords, limit access
3. **Environment Variables** - Never commit secrets
4. **Update Dependencies** - Keep packages up to date
5. **Input Validation** - Validate all user inputs
6. **Rate Limiting** - Implement rate limiting for API calls
7. **Backup Strategy** - Regular automated backups
8. **Access Control** - Implement proper authentication

## Performance Optimization

1. **Database Indexing** - Already configured in schema.sql
2. **Caching** - Use Streamlit's @st.cache_data
3. **Connection Pooling** - Use pgbouncer for PostgreSQL
4. **CDN** - Serve static files via CDN
5. **Compression** - Enable gzip compression

## Scaling

For high traffic:

1. **Horizontal Scaling** - Deploy multiple app instances behind load balancer
2. **Database Replication** - Read replicas for read-heavy operations
3. **Caching Layer** - Redis for session management
4. **CDN** - CloudFlare for static assets

## Troubleshooting

### Common Issues

**Connection refused:**
- Check database is running
- Verify firewall rules
- Check database credentials

**Out of memory:**
- Increase instance size
- Optimize database queries
- Implement pagination

**Slow performance:**
- Check database indexes
- Monitor query performance
- Implement caching

## Support

For deployment issues:
- Check application logs
- Review database logs
- Monitor system resources
- Check network connectivity

---

**Remember**: Always test in a staging environment before deploying to production!
