# Changelog

All notable changes to the Soirée project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2025-12-04

### Added
- Initial release of Soirée Event Venue Marketplace
- User authentication system with role-based access control
- Organizer features:
  - Smart venue search with filters
  - Venue details page with photos, packages, and reviews
  - Booking creation and management
  - Vendor browsing
  - Review submission system
- Venue Owner features:
  - Venue management (CRUD operations)
  - Package configuration with flexible pricing
  - Photo gallery management
  - Booking overview and management
  - Revenue analytics dashboard
- Vendor features:
  - Profile management
  - Booking association
  - Rating system
- Database schema with 10 core tables
- Sample data loading script
- Comprehensive documentation

### Fixed
- HTML rendering issues in booking card displays
- F-string interpolation causing raw HTML to display
- Emoji encoding issues in organizer contact information
- Price calculation bugs for per-plate vs fixed pricing
- Navigation state management across page transitions

### Security
- Password hashing using SHA-256
- SQL injection prevention through parameterized queries
- Session-based authentication
- Role-based access control

### Technical Details
- Built with Streamlit 1.28+
- PostgreSQL 12+ database backend
- Python 3.8+ support
- Responsive dark theme UI
- Real-time availability checking
- Automatic booking status updates

## [0.2.0] - 2025-12-03

### Fixed
- My Bookings page HTML rendering
- Venue Bookings page HTML rendering
- Extracted values to prevent f-string nesting issues
- Cleaned up HTML content generation
- Removed problematic emoji characters

### Changed
- Refactored booking card HTML generation
- Improved string concatenation for HTML building
- Enhanced code readability and maintainability

## [0.1.0] - 2025-10-15

### Added
- Part 1 submission: Database design
- ER diagram
- Relational schema
- Business rules documentation
- Initial schema.sql file

---

## Legend

- **Added**: New features
- **Changed**: Changes in existing functionality
- **Deprecated**: Soon-to-be removed features
- **Removed**: Removed features
- **Fixed**: Bug fixes
- **Security**: Security improvements
