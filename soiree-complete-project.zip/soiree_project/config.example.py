# Database Configuration Example
# Copy this section and update the values in project.py

DB_CONFIG = {
    'dbname': 'soiree_dtb',      # Database name
    'user': 'postgres',          # PostgreSQL username
    'password': 'your_password', # PostgreSQL password
    'host': 'localhost',         # Database host
    'port': '5432'              # PostgreSQL port (default: 5432)
}

# Common Configurations:

# Local Development (Default)
DB_CONFIG = {
    'dbname': 'soiree_dtb',
    'user': 'postgres',
    'password': 'your_password',
    'host': 'localhost',
    'port': '5432'
}

# Custom Port
DB_CONFIG = {
    'dbname': 'soiree_dtb',
    'user': 'postgres',
    'password': 'your_password',
    'host': 'localhost',
    'port': '5433'  # If using non-default port
}

# Remote PostgreSQL Server
DB_CONFIG = {
    'dbname': 'soiree_dtb',
    'user': 'your_username',
    'password': 'your_password',
    'host': '192.168.1.100',  # IP of remote server
    'port': '5432'
}

# Using Environment Variables (Recommended for Production)
import os

DB_CONFIG = {
    'dbname': os.getenv('DB_NAME', 'soiree_dtb'),
    'user': os.getenv('DB_USER', 'postgres'),
    'password': os.getenv('DB_PASSWORD'),
    'host': os.getenv('DB_HOST', 'localhost'),
    'port': os.getenv('DB_PORT', '5432')
}

# Docker PostgreSQL
DB_CONFIG = {
    'dbname': 'soiree_dtb',
    'user': 'postgres',
    'password': 'postgres',
    'host': 'localhost',  # or 'postgres' if running in same docker network
    'port': '5432'
}
