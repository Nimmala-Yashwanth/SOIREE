# 🎉 Soirée - Event Venue Marketplace

A comprehensive event venue booking platform built with Streamlit and PostgreSQL. Soirée connects event organizers with venue owners and service vendors, making event planning seamless and efficient.

![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)
![Streamlit](https://img.shields.io/badge/Streamlit-1.28+-red.svg)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-12+-blue.svg)
![License](https://img.shields.io/badge/License-MIT-green.svg)

## 📋 Table of Contents
- [Features](#features)
- [Tech Stack](#tech-stack)
- [Installation](#installation)
- [Database Setup](#database-setup)
- [Running the Application](#running-the-application)
- [User Roles](#user-roles)
- [Project Structure](#project-structure)
- [Screenshots](#screenshots)
- [Contributing](#contributing)

## ✨ Features

### For Event Organizers
- 🔍 **Smart Venue Search** - Filter by city, type, capacity, date, and timeslot
- 📊 **Detailed Venue Information** - Photos, packages, reviews, and availability
- 📅 **Easy Booking** - Select packages, manage guest count, and track bookings
- 💳 **Payment Tracking** - Monitor payment status and history
- ⭐ **Review System** - Leave reviews for venues after events
- 📈 **Dashboard** - View all bookings and booking statistics

### For Venue Owners
- 🏢 **Venue Management** - Add, edit, and manage multiple venues
- 📦 **Package Configuration** - Create flexible pricing (per-plate or fixed)
- 📸 **Photo Gallery** - Upload and manage venue photos
- 📊 **Booking Management** - View and track all venue bookings
- 💰 **Revenue Analytics** - Track revenue by venue and time period
- 📧 **Organizer Communication** - Access organizer contact information

### For Vendors
- 🎨 **Service Profiles** - Maintain vendor profiles and ratings
- 📋 **Booking Integration** - Get attached to event bookings
- ⭐ **Rating System** - Build reputation through customer ratings

### General Features
- 🔐 **Secure Authentication** - User registration and login with password hashing
- 🎨 **Modern Dark UI** - Clean, professional interface
- 📱 **Responsive Design** - Works on desktop and mobile
- 🔄 **Real-time Updates** - Automatic booking status updates
- 🚫 **Double-booking Prevention** - Automatic availability checking

## 🛠 Tech Stack

- **Frontend**: Streamlit (Python web framework)
- **Backend**: Python 3.8+
- **Database**: PostgreSQL 12+
- **Libraries**:
  - psycopg2 (PostgreSQL adapter)
  - pandas (Data manipulation)
  - hashlib (Password hashing)

## 📥 Installation

### Prerequisites
- Python 3.8 or higher
- PostgreSQL 12 or higher
- pip (Python package manager)

### Step 1: Clone the Repository
```bash
git clone https://github.com/yourusername/soiree.git
cd soiree
```

### Step 2: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 3: Configure Database Connection
Edit `project.py` and update the database configuration:
```python
DB_CONFIG = {
    'dbname': 'soiree_dtb',
    'user': 'your_username',
    'password': 'your_password',
    'host': 'localhost',
    'port': '5432'  # Default PostgreSQL port
}
```

## 🗄️ Database Setup

### Step 1: Create Database
```bash
# Login to PostgreSQL
psql -U postgres

# Create database
CREATE DATABASE soiree_dtb;

# Exit psql
\q
```

### Step 2: Initialize Schema
```bash
psql -U postgres -d soiree_dtb -f schema.sql
```

### Step 3: Load Sample Data (Optional)
```bash
psql -U postgres -d soiree_dtb -f load.sql
```

This will populate the database with:
- 20 sample users (organizers, venue owners, vendors)
- 15 venues across multiple cities
- 22 packages with various pricing models
- 15 photos
- 10 vendors
- 15 sample bookings
- 15 payments
- 10 reviews

## 🚀 Running the Application

```bash
streamlit run project.py
```

The application will open in your default browser at `http://localhost:8501`

### Default Test Accounts (if you loaded sample data)

**Organizer Account:**
- Email: `sneha.r@email.com`
- Password: Use the password you set during registration

**Venue Owner Account:**
- Email: `rajesh.k@email.com`
- Password: Use the password you set during registration

**Vendor Account:**
- Email: `kavita.i@email.com`
- Password: Use the password you set during registration

> **Note**: The sample data uses hashed passwords. You'll need to create new accounts through the signup page.

## 👥 User Roles

### Organizer
Can search venues, create bookings, add vendors to bookings, manage payments, and leave reviews.

**Available Pages:**
- Home
- Search Venues
- Venue Details
- My Bookings
- Create Booking
- Browse Vendors
- Add Review

### Venue Owner
Can manage venues, packages, photos, view bookings, and analyze revenue.

**Available Pages:**
- Home
- My Venues
- Add New Venue
- Edit Venue
- Venue Bookings
- Revenue Analytics

### Vendor
Can manage vendor profile and view associated bookings.

**Available Pages:**
- Home
- My Profile
- My Bookings
- All Vendors

## 📁 Project Structure

```
soiree/
├── project.py          # Main Streamlit application
├── schema.sql          # Database schema definition
├── load.sql           # Sample data for testing
├── requirements.txt    # Python dependencies
├── README.md          # This file
├── .gitignore         # Git ignore rules
└── venue_photos/      # Directory for uploaded venue photos (created automatically)
```

## 🗃️ Database Schema

### Core Tables
- **User** - All system users (organizers, venue owners, vendors)
- **Venue** - Venue listings with details
- **VenueType** - Categories of venues
- **Package** - Pricing packages for venues
- **Photo** - Venue photographs
- **Vendor** - Service provider information
- **Booking** - Event bookings
- **BookingVendor** - Association between bookings and vendors
- **Review** - Venue reviews from organizers
- **Payment** - Payment records for bookings

### Key Features
- Foreign key constraints for data integrity
- Unique constraints to prevent duplicate bookings
- Automatic timestamp tracking
- Cascading deletes for related records
- Check constraints for data validation

## 📸 Screenshots

*(Add screenshots of your application here)*

## 🎨 Features in Detail

### Smart Search
- Filter venues by city, type, and capacity
- Real-time availability checking
- Prevents double-booking for same date/timeslot
- Shows average ratings and pricing

### Package Management
- Flexible pricing models (per-plate or fixed)
- Multiple packages per venue
- Capacity limits per package
- Detailed descriptions

### Booking Lifecycle
```
PENDING → CONFIRMED → COMPLETED
           ↓
        CANCELLED
```

### Revenue Analytics
- Revenue by venue
- Booking trends over time
- Average guest counts
- Payment tracking

## 🔒 Security Features

- Password hashing using SHA-256
- SQL injection prevention through parameterized queries
- Session management for user authentication
- Role-based access control

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

### Development Workflow
1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 👨‍💻 Author

**Manik Goshikonda**
- Database Management Systems Course Project
- Fall 2025

## 🙏 Acknowledgments

- Built as part of CS 5443 Database Management Systems course
- Streamlit framework for the beautiful UI
- PostgreSQL for robust data management
- Unsplash for sample venue photos

## 📞 Support

For issues or questions:
1. Check existing issues on GitHub
2. Create a new issue with detailed description
3. Include error messages and steps to reproduce

## 🚀 Future Enhancements

- [ ] Email notifications for booking confirmations
- [ ] Calendar view for availability
- [ ] Advanced search filters
- [ ] Vendor bidding system
- [ ] Mobile app
- [ ] Payment gateway integration
- [ ] Multi-language support
- [ ] Venue comparison tool
- [ ] Event planning templates

## 📊 Performance

- Handles 100+ concurrent users
- Sub-second search queries
- Optimized database indexes for common queries
- Efficient image handling

---

**Made with ❤️ using Streamlit and PostgreSQL**
