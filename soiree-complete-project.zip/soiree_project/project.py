import streamlit as st
import psycopg2
from psycopg2 import sql
from datetime import datetime, date
import pandas as pd
import hashlib
import os
from pathlib import Path
import base64

# Database connection parameters
DB_CONFIG = {
    'dbname': 'soiree_dtb',
    'user': 'postgres',
    'password': 'Mine4453',  
    'host': 'localhost',
    'port': '5433'
}

# Create photos directory if it doesn't exist
PHOTOS_DIR = Path("venue_photos")
PHOTOS_DIR.mkdir(exist_ok=True)

def save_uploaded_file(uploaded_file, venue_id):
    """Save uploaded file and return the file path"""
    if uploaded_file is not None:
        # Create venue-specific folder
        venue_folder = PHOTOS_DIR / f"venue_{venue_id}"
        venue_folder.mkdir(exist_ok=True)
        
        # Save file
        file_path = venue_folder / uploaded_file.name
        with open(file_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
        
        # Return relative path for database
        return f"venue_photos/venue_{venue_id}/{uploaded_file.name}"
    return None

def get_connection():
    """Create database connection"""
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        return conn
    except Exception as e:
        st.error(f"Database connection error: {e}")
        return None

def execute_query(query, params=None, fetch=True):
    """Execute a database query"""
    conn = get_connection()
    if not conn:
        return None
    
    try:
        # Convert numpy types to Python types if params exist
        if params:
            params = tuple(int(p) if hasattr(p, 'item') else p for p in params)
        
        cur = conn.cursor()
        cur.execute(query, params)
        if fetch:
            result = cur.fetchall()
            columns = [desc[0] for desc in cur.description] if cur.description else []
            conn.close()
            return pd.DataFrame(result, columns=columns) if result else pd.DataFrame()
        else:
            conn.commit()
            conn.close()
            return True
    except Exception as e:
        st.error(f"Query error: {e}")
        if conn:
            conn.close()
        return None

def update_booking_status():
    """Auto-update booking status based on date"""
    query = """
        UPDATE Booking 
        SET status = 'COMPLETED'
        WHERE booking_date < CURRENT_DATE 
        AND status IN ('CONFIRMED', 'PENDING')
    """
    execute_query(query, fetch=False)

def hash_password(password):
    """Hash password using SHA256"""
    return hashlib.sha256(password.encode()).hexdigest()

def verify_login(email, password):
    """Verify user credentials"""
    query = 'SELECT user_id, name, email, role, password_hash FROM "User" WHERE email = %s'
    df = execute_query(query, (email,))
    
    if df is not None and not df.empty:
        stored_hash = df.iloc[0]['password_hash']
        input_hash = hash_password(password)
        
        if stored_hash == input_hash:
            return {
                'user_id': df.iloc[0]['user_id'],
                'name': df.iloc[0]['name'],
                'email': df.iloc[0]['email'],
                'role': df.iloc[0]['role']
            }
    return None

def register_user(name, email, phone, password, role):
    """Register a new user"""
    # Check if email already exists
    check_query = 'SELECT email FROM "User" WHERE email = %s'
    existing = execute_query(check_query, (email,))
    
    if existing is not None and not existing.empty:
        return False, "Email already exists"
    
    # Insert new user
    password_hash = hash_password(password)
    insert_query = '''
        INSERT INTO "User" (name, email, phone, password_hash, role)
        VALUES (%s, %s, %s, %s, %s)
    '''
    result = execute_query(insert_query, (name, email, phone, password_hash, role), fetch=False)
    
    if result:
        return True, "Registration successful! Please login."
    return False, "Registration failed. Please try again."

# Initialize session state
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
if 'user' not in st.session_state:
    st.session_state.user = None
if 'current_page' not in st.session_state:
    st.session_state.current_page = "Home"

# Page configuration
st.set_page_config(page_title="SoirÃ©e - Event Venue Marketplace", page_icon="ðŸŽ‰", layout="wide")

# Custom CSS for better styling
st.markdown("""
    <style>
    /* Main background - Clean black */
    .stApp {
        background-color: #0a0a0a;
    }
    
    /* Sidebar styling - Dark grey */
    [data-testid="stSidebar"] {
        background-color: #1a1a1a;
    }
    
    /* Headers - White text */
    h1, h2, h3 {
        color: #ffffff !important;
        font-weight: 600 !important;
    }
    
    /* Remove default padding */
    .block-container {
        padding-top: 2rem;
    }
    
    /* Buttons - Simple white outline */
    .stButton > button {
        background-color: transparent;
        color: white;
        border: 2px solid white;
        padding: 10px 24px;
        border-radius: 8px;
        font-weight: 500;
        transition: all 0.3s;
    }
    
    .stButton > button:hover {
        background-color: white;
        color: black;
    }
    
    /* Forms - Dark inputs */
    .stTextInput > div > div > input,
    .stSelectbox > div > div > select,
    .stTextArea > div > div > textarea,
    .stDateInput > div > div > input,
    .stNumberInput > div > div > input {
        background-color: #2a2a2a;
        color: white;
        border: 1px solid #3a3a3a;
        border-radius: 6px;
    }
    
    /* Dataframes - Dark theme */
    .dataframe {
        background-color: #1a1a1a !important;
        color: white !important;
    }
    
    /* Success/Error messages - Minimal */
    .stSuccess {
        background-color: rgba(40, 167, 69, 0.15);
        border-left: 3px solid #28a745;
        color: white;
    }
    
    .stError {
        background-color: rgba(220, 53, 69, 0.15);
        border-left: 3px solid #dc3545;
        color: white;
    }
    
    .stInfo {
        background-color: rgba(255, 255, 255, 0.1);
        border-left: 3px solid white;
        color: white;
    }
    
    /* Tabs */
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px;
        background-color: transparent;
        border-bottom: none;
    }
    
    .stTabs [data-baseweb="tab"] {
        background-color: transparent;
        border: 1px solid #3a3a3a;
        color: white;
        border-radius: 6px;
    }
    
    .stTabs [aria-selected="true"] {
        background-color: white;
        color: black;
        border: 1px solid white;
    }
    
    .stTabs [data-baseweb="tab-highlight"] {
        display: none;
    }
    
    .stTabs [data-baseweb="tab-border"] {
        display: none;
    }
    
    /* Metrics */
    [data-testid="stMetricValue"] {
        color: white;
    }
    
    /* Labels */
    label {
        color: rgba(255, 255, 255, 0.8) !important;
    }
    </style>
    """, unsafe_allow_html=True)

# LOGIN/SIGNUP PAGE
if not st.session_state.logged_in:
    st.markdown("<div style='height: 60px;'></div>", unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        st.markdown("<h1 style='text-align: center; color: white; font-size: 3.5em; margin-bottom: 5px;'>SoirÃ©e</h1>", unsafe_allow_html=True)
        st.markdown("<p style='text-align: center; color: rgba(255,255,255,0.6); margin-bottom: 60px; font-size: 1.2em;'>Event Venue Marketplace</p>", unsafe_allow_html=True)
        
        tab1, tab2 = st.tabs(["Sign in", "Sign up"])
        
        with tab1:
            st.markdown("<div style='height: 30px;'></div>", unsafe_allow_html=True)
            with st.form("login_form"):
                st.text_input("Email", key="login_email", placeholder="your.email@example.com")
                st.markdown("<div style='height: 10px;'></div>", unsafe_allow_html=True)
                st.text_input("Password", type="password", key="login_password", placeholder="Enter password")
                
                st.markdown("<div style='height: 25px;'></div>", unsafe_allow_html=True)
                submit = st.form_submit_button("Login", use_container_width=True)
                
                if submit:
                    email = st.session_state.login_email
                    password = st.session_state.login_password
                    if email and password:
                        user = verify_login(email, password)
                        if user:
                            st.session_state.logged_in = True
                            st.session_state.user = user
                            st.success(f"Welcome back, {user['name']}!")
                            st.rerun()
                        else:
                            st.error("Invalid email or password")
                    else:
                        st.warning("Please enter both email and password")
        
        with tab2:
            st.markdown("<div style='height: 30px;'></div>", unsafe_allow_html=True)
            with st.form("signup_form"):
                st.text_input("Full Name", key="signup_name", placeholder="John Doe")
                st.markdown("<div style='height: 10px;'></div>", unsafe_allow_html=True)
                st.text_input("Email", key="signup_email", placeholder="your.email@example.com")
                st.markdown("<div style='height: 10px;'></div>", unsafe_allow_html=True)
                st.text_input("Phone Number", key="signup_phone", placeholder="+1 234 567 8900")
                st.markdown("<div style='height: 10px;'></div>", unsafe_allow_html=True)
                
                col_a, col_b = st.columns(2)
                with col_a:
                    st.text_input("Password", type="password", key="signup_password", placeholder="Min 6 characters")
                with col_b:
                    st.text_input("Confirm Password", type="password", key="signup_confirm", placeholder="Re-enter password")
                
                st.markdown("<div style='height: 10px;'></div>", unsafe_allow_html=True)
                st.selectbox("I am a:", ["organizer", "venue_owner", "vendor"], key="signup_role")
                
                st.markdown("<div style='height: 25px;'></div>", unsafe_allow_html=True)
                submit = st.form_submit_button("Sign Up", use_container_width=True)
                
                if submit:
                    name = st.session_state.signup_name
                    email = st.session_state.signup_email
                    phone = st.session_state.signup_phone
                    password = st.session_state.signup_password
                    confirm_password = st.session_state.signup_confirm
                    role = st.session_state.signup_role
                    
                    if not all([name, email, phone, password, confirm_password]):
                        st.warning("Please fill in all fields")
                    elif password != confirm_password:
                        st.error("Passwords do not match")
                    elif len(password) < 6:
                        st.error("Password must be at least 6 characters")
                    else:
                        success, message = register_user(name, email, phone, password, role)
                        if success:
                            st.success(message)
                        else:
                            st.error(message)

# MAIN APPLICATION (After Login)
else:
    # Update booking statuses first
    update_booking_status()
    
    # Sidebar with user info and logout
    with st.sidebar:
        st.markdown(f"<h3 style='text-align: center;'>{st.session_state.user['name']}</h3>", unsafe_allow_html=True)
        st.markdown(f"<p style='text-align: center; color: rgba(255,255,255,0.6); font-size: 0.9em;'>{st.session_state.user['role'].replace('_', ' ').title()}</p>", unsafe_allow_html=True)
        
        if st.button("Logout", use_container_width=True):
            st.session_state.logged_in = False
            st.session_state.user = None
            st.rerun()
        
        st.markdown("---")
    
    # Navigation based on user role
    user_role = st.session_state.user['role']
    
    # Determine which page list to use
    if user_role == 'organizer':
        pages = ["Home", "Search Venues", "Venue Details", "My Bookings", "Create Booking", "Browse Vendors", "Add Review"]
    elif user_role == 'venue_owner':
        pages = ["Home", "My Venues", "Add New Venue", "Edit Venue", "Venue Bookings", "Revenue Analytics"]
    elif user_role == 'vendor':
        pages = ["Home", "My Profile", "My Bookings", "All Vendors"]
    else:
        pages = ["Home", "All Venues", "All Bookings", "Analytics"]
    
    # Initialize current page if not exists
    if 'current_page' not in st.session_state:
        st.session_state.current_page = "Home"
    
    # Make sure current page is valid for this role
    if st.session_state.current_page not in pages:
        st.session_state.current_page = pages[0]
    
    with st.sidebar:
        st.subheader("Navigation")
        
        # Find index of current page
        current_index = pages.index(st.session_state.current_page)
        
        # Simple selectbox - when it changes, update current_page
        new_page = st.selectbox("Navigation", pages, index=current_index, label_visibility="collapsed")
        
        if new_page != st.session_state.current_page:
            st.session_state.current_page = new_page
            st.rerun()
    
    # Use current_page from session state
    page = st.session_state.current_page
    
    # Main title
    st.title(f"SoirÃ©e - {page}")
    st.markdown("---")
    
    # HOME PAGE
    if page == "Home":
        st.markdown(f"<h2 style='color: white;'>Welcome back, {st.session_state.user['name']}</h2>", unsafe_allow_html=True)
        st.markdown("<br>", unsafe_allow_html=True)
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown("### ðŸ“Š Platform Statistics")
            query = """
                SELECT v.city, COUNT(v.venue_id) as venue_count, vt.name as venue_type
                FROM Venue v
                JOIN VenueType vt ON v.venue_type_id = vt.venue_type_id
                GROUP BY v.city, vt.name
                ORDER BY venue_count DESC
                LIMIT 10
            """
            df = execute_query(query)
            if df is not None and not df.empty:
                st.dataframe(df, use_container_width=True, height=300)
        
        with col2:
            st.markdown("### â­ Top Rated Venues")
            query = """
                SELECT v.name, v.city, AVG(r.rating) as avg_rating, COUNT(r.review_id) as review_count
                FROM Venue v
                JOIN Review r ON v.venue_id = r.venue_id
                GROUP BY v.venue_id, v.name, v.city
                HAVING COUNT(r.review_id) >= 1
                ORDER BY avg_rating DESC, review_count DESC
                LIMIT 5
            """
            df = execute_query(query)
            if df is not None and not df.empty:
                st.dataframe(df, use_container_width=True, height=300)
        
        with col3:
            st.markdown("### ðŸ“ˆ Your Statistics")
            if user_role == 'organizer':
                query = """
                    SELECT COUNT(*) as my_bookings
                    FROM Booking
                    WHERE organizer_id = %s AND status = 'CONFIRMED'
                """
                df = execute_query(query, (st.session_state.user['user_id'],))
                if df is not None and not df.empty:
                    st.metric("My Confirmed Bookings", df['my_bookings'].iloc[0], delta="Active")
                    
                query2 = """
                    SELECT COUNT(*) as total_bookings
                    FROM Booking
                    WHERE organizer_id = %s
                """
                df2 = execute_query(query2, (st.session_state.user['user_id'],))
                if df2 is not None and not df2.empty:
                    st.metric("Total Bookings", df2['total_bookings'].iloc[0])
                    
            elif user_role == 'venue_owner':
                query = """
                    SELECT COUNT(*) as my_venues
                    FROM Venue
                    WHERE owner_id = %s
                """
                df = execute_query(query, (st.session_state.user['user_id'],))
                if df is not None and not df.empty:
                    st.metric("My Venues", df['my_venues'].iloc[0])
                    
                query2 = """
                    SELECT COUNT(b.booking_id) as total_bookings
                    FROM Venue v
                    JOIN Booking b ON v.venue_id = b.venue_id
                    WHERE v.owner_id = %s
                """
                df2 = execute_query(query2, (st.session_state.user['user_id'],))
                if df2 is not None and not df2.empty:
                    st.metric("Total Bookings", df2['total_bookings'].iloc[0])
    
    # SEARCH VENUES (Organizer)
    elif page == "Search Venues":
        st.header("Search Venues")
        
        # Define callback function for View Details button
        def navigate_to_venue(venue_id):
            st.session_state.selected_venue_id = int(venue_id)
            st.session_state.current_page = "Venue Details"
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            cities_query = "SELECT DISTINCT city FROM Venue ORDER BY city"
            cities_df = execute_query(cities_query)
            cities = ['All'] + cities_df['city'].tolist() if cities_df is not None and not cities_df.empty else ['All']
            selected_city = st.selectbox("Select City", cities)
        
        with col2:
            types_query = "SELECT venue_type_id, name FROM VenueType ORDER BY name"
            types_df = execute_query(types_query)
            venue_types = ['All'] + types_df['name'].tolist() if types_df is not None and not types_df.empty else ['All']
            selected_type = st.selectbox("Venue Type", venue_types)
        
        with col3:
            min_capacity = st.number_input("Minimum Capacity", min_value=0, value=100)
        
        search_date = st.date_input("Event Date", value=date.today())
        timeslot = st.selectbox("Time Slot", ["morning", "afternoon", "evening"])
        
        if st.button("Search Venues"):
            query = """
                SELECT DISTINCT v.venue_id, v.name, v.city, vt.name as venue_type, 
                       v.max_capacity, v.base_price, v.description,
                       COALESCE(AVG(r.rating), 0) as avg_rating,
                       p.url as photo_url
                FROM Venue v
                JOIN VenueType vt ON v.venue_type_id = vt.venue_type_id
                LEFT JOIN Review r ON v.venue_id = r.venue_id
                LEFT JOIN Photo p ON v.venue_id = p.venue_id AND p.is_primary = TRUE
                WHERE v.max_capacity >= %s
                    AND (%s = 'All' OR v.city = %s)
                    AND (%s = 'All' OR vt.name = %s)
                    AND NOT EXISTS (
                        SELECT 1 FROM Booking b
                        WHERE b.venue_id = v.venue_id
                        AND b.booking_date = %s
                        AND b.timeslot = %s
                        AND b.status IN ('CONFIRMED', 'PENDING')
                    )
                GROUP BY v.venue_id, v.name, v.city, vt.name, v.max_capacity, v.base_price, v.description, p.url
                ORDER BY avg_rating DESC, v.base_price
            """
            params = (min_capacity, selected_city, selected_city, selected_type, selected_type, search_date, timeslot)
            df = execute_query(query, params)
            
            # Store results in session state
            st.session_state.search_results = df
        
        # Display results from session state (persists across reruns)
        if 'search_results' in st.session_state and st.session_state.search_results is not None:
            df = st.session_state.search_results
            
            if not df.empty:
                st.success(f"Found {len(df)} available venues")
                
                # Display as cards (2 per row)
                for i in range(0, len(df), 2):
                    cols = st.columns(2)
                    for j, col in enumerate(cols):
                        if i + j < len(df):
                            venue = df.iloc[i + j]
                            with col:
                                # Get photo URL
                                photo_url = None
                                if pd.notna(venue['photo_url']):
                                    photo_url = venue['photo_url']
                                    if photo_url.startswith('venue_photos/') and not os.path.exists(photo_url):
                                        photo_url = None
                                
                                if not photo_url:
                                    photo_url = 'https://images.unsplash.com/photo-1519167758481-83f29da8a1c4'
                                
                                st.markdown(f"""
                                <div style='background-color: #1a1a1a; border-radius: 10px; overflow: hidden; margin-bottom: 20px; border: 1px solid #2a2a2a;'>
                                """, unsafe_allow_html=True)
                                
                                if photo_url.startswith('venue_photos/'):
                                    st.image(photo_url, use_container_width=True)
                                else:
                                    st.image(photo_url, use_container_width=True)
                                
                                st.markdown(f"""
                                <div style='padding: 20px;'>
                                    <div style='display: flex; justify-content: space-between; align-items: start;'>
                                        <div>
                                            <h3 style='margin: 0 0 8px 0;'>{venue['name']}</h3>
                                            <p style='color: rgba(255,255,255,0.6); margin: 4px 0;'>ðŸ“ {venue['city']} - {venue['venue_type']}</p>
                                        </div>
                                        <div style='background: rgba(255,215,0,0.15); padding: 4px 12px; border-radius: 20px;'>
                                            <span style='color: #ffd700;'>â­ {venue['avg_rating']:.1f}</span>
                                        </div>
                                    </div>
                                    <p style='color: rgba(255,255,255,0.8); margin: 12px 0;'>{venue['description'][:120]}...</p>
                                    <p style='color: rgba(255,255,255,0.6); margin: 8px 0;'>ðŸ‘¥ Up to {venue['max_capacity']} guests</p>
                                    <p style='font-size: 1.5em; color: white; font-weight: 600; margin: 12px 0;'>${float(venue['base_price']):,.0f}</p>
                                </div>
                                </div>
                                """, unsafe_allow_html=True)
                                
                                button_key = f"view_detail_{venue['venue_id']}_{i}_{j}"
                                st.button("View Details", key=button_key, use_container_width=True, 
                                         on_click=lambda v_id=venue['venue_id']: navigate_to_venue(v_id))
            else:
                st.warning("No venues found matching your criteria")
    
    # VENUE DETAILS
    elif page == "Venue Details":
        st.header("Venue Details")
        
        # Check if coming from search with a selected venue
        venue_id = st.session_state.get('selected_venue_id', None)
        
        # Get all venues for dropdown
        venues_query = "SELECT venue_id, name, city FROM Venue ORDER BY name"
        venues_df = execute_query(venues_query)
        
        if venues_df is not None and not venues_df.empty:
            venue_options = {f"{row['name']} - {row['city']}": int(row['venue_id']) 
                            for _, row in venues_df.iterrows()}
            
            # Find default index if venue was pre-selected
            default_index = 0
            if venue_id:
                for idx, (key, vid) in enumerate(venue_options.items()):
                    if vid == venue_id:
                        default_index = idx
                        break
                # Clear it after using
                if 'selected_venue_id' in st.session_state:
                    del st.session_state.selected_venue_id
            
            selected_venue = st.selectbox("Select a Venue", list(venue_options.keys()), index=default_index)
            venue_id = venue_options[selected_venue]
        else:
            st.error("No venues available")
            venue_id = None
        
        if venue_id:
            query = """
                SELECT v.*, vt.name as venue_type, u.name as owner_name, u.phone as owner_phone
                FROM Venue v
                JOIN VenueType vt ON v.venue_type_id = vt.venue_type_id
                JOIN "User" u ON v.owner_id = u.user_id
                WHERE v.venue_id = %s
            """
            venue_df = execute_query(query, (venue_id,))
            
            if venue_df is not None and not venue_df.empty:
                venue = venue_df.iloc[0]
                
                col1, col2 = st.columns(2)
                with col1:
                    st.subheader("Venue Information")
                    st.write(f"**Name:** {venue['name']}")
                    st.write(f"**Type:** {venue['venue_type']}")
                    st.write(f"**City:** {venue['city']}")
                    st.write(f"**Address:** {venue['address']}")
                    st.write(f"**Capacity:** {venue['max_capacity']} guests")
                    st.write(f"**Base Price:** ${float(venue['base_price']):,.0f}")
                    st.write(f"**Owner:** {venue['owner_name']} ({venue['owner_phone']})")
                
                with col2:
                    st.subheader("Photos")
                    photos_query = "SELECT url, caption FROM Photo WHERE venue_id = %s LIMIT 5"
                    photos_df = execute_query(photos_query, (venue_id,))
                    if photos_df is not None and not photos_df.empty:
                        for _, photo in photos_df.iterrows():
                            if photo['url'].startswith('venue_photos/'):
                                if os.path.exists(photo['url']):
                                    st.image(photo['url'], caption=photo['caption'], width=300)
                            else:
                                st.image(photo['url'], caption=photo['caption'], width=300)
                
                st.subheader("Available Packages")
                packages_query = """
                    SELECT name, price, price_per_plate, max_capacity, description
                    FROM Package
                    WHERE venue_id = %s
                """
                packages_df = execute_query(packages_query, (venue_id,))
                if packages_df is not None and not packages_df.empty:
                    st.dataframe(packages_df, use_container_width=True)
                
                st.subheader("Reviews")
                reviews_query = """
                    SELECT u.name as reviewer, r.rating, r.comment, r.created_at
                    FROM Review r
                    JOIN "User" u ON r.organizer_id = u.user_id
                    WHERE r.venue_id = %s
                    ORDER BY r.created_at DESC
                """
                reviews_df = execute_query(reviews_query, (venue_id,))
                if reviews_df is not None and not reviews_df.empty:
                    for _, review in reviews_df.iterrows():
                        st.write(f"**{review['reviewer']}** - {'â­' * review['rating']}")
                        st.write(f"{review['comment']}")
                        st.write(f"*{review['created_at']}*")
                        st.markdown("---")
    
    # MY BOOKINGS (Organizer)
    elif page == "My Bookings":
        st.header("My Bookings")
        
        query = """
            SELECT b.booking_id, v.name as venue, v.city, v.venue_id,
                   b.booking_date, b.timeslot, b.guests_count, 
                   b.total_price, b.status, p.name as package_name,
                   ph.url as photo_url
            FROM Booking b
            JOIN Venue v ON b.venue_id = v.venue_id
            LEFT JOIN Package p ON b.package_id = p.package_id
            LEFT JOIN Photo ph ON v.venue_id = ph.venue_id AND ph.is_primary = TRUE
            WHERE b.organizer_id = %s
            ORDER BY b.booking_date DESC
        """
        df = execute_query(query, (st.session_state.user['user_id'],))
        
        if df is not None and not df.empty:
            # Display as cards (2 per row)
            for i in range(0, len(df), 2):
                cols = st.columns(2)
                for j, col in enumerate(cols):
                    if i + j < len(df):
                        booking = df.iloc[i + j]
                        with col:
                            # Get photo URL
                            photo_url = None
                            if pd.notna(booking['photo_url']):
                                photo_url = booking['photo_url']
                                if photo_url.startswith('venue_photos/') and not os.path.exists(photo_url):
                                    photo_url = None
                            
                            if not photo_url:
                                photo_url = 'https://images.unsplash.com/photo-1519167758481-83f29da8a1c4'
                            
                            # Status color
                            status_colors = {
                                'PENDING': '#ffa500',
                                'CONFIRMED': '#00d4ff',
                                'COMPLETED': '#28a745',
                                'CANCELLED': '#dc3545'
                            }
                            status_color = status_colors.get(booking['status'], '#ffffff')
                            
                            # Format price - convert Decimal to float
                            price_value = float(booking['total_price']) if booking['total_price'] else 0
                            price_str = f"${price_value:,.0f}"
                            
                            # Display image first
                            st.image(photo_url, use_container_width=True)
                            
                            # Build HTML content to avoid f-string nesting issues
                            venue_name = str(booking['venue'])
                            city_name = str(booking['city'])
                            booking_date = str(booking['booking_date'])
                            timeslot_title = str(booking['timeslot']).title()
                            guests = str(booking['guests_count'])
                            status = str(booking['status'])
                            
                            html_content = f"""<div style='background-color: #1a1a1a; padding: 20px; border-radius: 0 0 10px 10px; margin-top: -10px; border: 1px solid #2a2a2a;'>
                                <div style='display: flex; justify-content: space-between; align-items: start;'>
                                    <div>
                                        <h3 style='margin: 0 0 8px 0; color: white;'>{venue_name}</h3>
                                        <p style='color: rgba(255,255,255,0.6); margin: 4px 0;'>{city_name}</p>
                                    </div>
                                    <div style='background: rgba(255,255,255,0.1); padding: 6px 14px; border-radius: 20px; border: 2px solid {status_color};'>
                                        <span style='color: {status_color}; font-weight: 600;'>{status}</span>
                                    </div>
                                </div>
                                <p style='color: rgba(255,255,255,0.6); margin: 12px 0;'>{booking_date} - {timeslot_title}</p>
                                <p style='color: rgba(255,255,255,0.6); margin: 8px 0;'>{guests} guests</p>"""
                            
                            # Add package info if exists
                            if pd.notna(booking['package_name']):
                                pkg_name = str(booking['package_name'])
                                html_content += f"""\n                                <p style='color: rgba(255,255,255,0.6); margin: 8px 0;'>Package: {pkg_name}</p>"""
                            
                            # Add price and close
                            html_content += f"""\n                                <p style='font-size: 1.4em; color: white; font-weight: 600; margin: 12px 0;'>{price_str}</p>
                            </div>"""
                            
                            st.markdown(html_content, unsafe_allow_html=True)
            
            st.markdown("---")
            st.subheader("Booking Summary")
            summary_col1, summary_col2, summary_col3 = st.columns(3)
            with summary_col1:
                st.metric("Total Bookings", len(df))
            with summary_col2:
                confirmed = len(df[df['status'] == 'CONFIRMED'])
                st.metric("Confirmed", confirmed)
            with summary_col3:
                total_spent = float(df[df['status'].isin(['CONFIRMED', 'COMPLETED'])]['total_price'].sum())
                st.metric("Total Spent", f"${total_spent:,.0f}")
        else:
            st.info("You don't have any bookings yet. Start by searching for venues!")
    
    # CREATE BOOKING (Organizer)
    elif page == "Create Booking":
        st.header("Create New Booking")
        
        venues_query = "SELECT venue_id, name, city, max_capacity FROM Venue ORDER BY name"
        venues_df = execute_query(venues_query)
        
        if venues_df is not None and not venues_df.empty:
            venue_options = {f"{row['name']} - {row['city']} (Cap: {row['max_capacity']})": int(row['venue_id']) 
                           for _, row in venues_df.iterrows()}
            
            selected_venue_str = st.selectbox("Select Venue", list(venue_options.keys()), key="venue_select")
            selected_venue_id = venue_options[selected_venue_str]
            
            packages_query = """
                SELECT package_id, name, price, price_per_plate, max_capacity 
                FROM Package WHERE venue_id = %s
            """
            packages_df = execute_query(packages_query, (selected_venue_id,))
            
            with st.form("booking_form"):
                booking_date = st.date_input("Booking Date", min_value=date.today())
                timeslot = st.selectbox("Timeslot", ["morning", "afternoon", "evening"])
                guests_count = st.number_input("Number of Guests", min_value=1, value=100)
                
                package_id = None
                selected_pkg_price = 0
                selected_pkg_per_plate = False
                
                if packages_df is not None and not packages_df.empty:
                    # Create package options with price info
                    pkg_options = {}
                    pkg_details = {}
                    for _, row in packages_df.iterrows():
                        price_type = "per plate" if row['price_per_plate'] else "fixed"
                        label = f"{row['name']} - ${float(row['price']):,.0f} ({price_type})"
                        pkg_options[label] = int(row['package_id'])
                        pkg_details[int(row['package_id'])] = {
                            'price': float(row['price']),
                            'per_plate': row['price_per_plate']
                        }
                    
                    selected_package = st.selectbox("Select Package", ["None"] + list(pkg_options.keys()))
                    
                    if selected_package != "None":
                        package_id = pkg_options[selected_package]
                        selected_pkg_price = pkg_details[package_id]['price']
                        selected_pkg_per_plate = pkg_details[package_id]['per_plate']
                        
                        # Show estimated price
                        if selected_pkg_per_plate:
                            est_price = selected_pkg_price * guests_count
                            st.info(f"Estimated Total: ${est_price:,.0f} (${selected_pkg_price:,.0f} x {guests_count} guests)")
                        else:
                            st.info(f"Package Price: ${selected_pkg_price:,.0f} (fixed price)")
                else:
                    st.info("No packages available for this venue")
                
                submitted = st.form_submit_button("Create Booking", use_container_width=True)
                
                if submitted:
                    # Calculate total price based on package
                    if package_id is not None:
                        if selected_pkg_per_plate:
                            total_price = selected_pkg_price * guests_count
                        else:
                            total_price = selected_pkg_price
                    else:
                        # No package selected - use venue base price or default
                        total_price = guests_count * 1500  # Default rate
                    
                    insert_query = """
                        INSERT INTO Booking (venue_id, organizer_id, package_id, booking_date, 
                                            timeslot, guests_count, total_price, status)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, 'PENDING')
                    """
                    params = (selected_venue_id, st.session_state.user['user_id'], package_id, booking_date, 
                             timeslot, guests_count, total_price)
                    
                    result = execute_query(insert_query, params, fetch=False)
                    if result:
                        st.success(f"Booking created successfully! Total: ${total_price:,.0f}")
                        st.balloons()
                    else:
                        st.error("Failed to create booking. The venue might already be booked for this time slot.")
        else:
            st.error("No venues available")
    
    # MY VENUES (Venue Owner)
    elif page == "My Venues":
        st.header("My Venues")
        
        # Define callback function
        def navigate_to_edit_venue(venue_id):
            st.session_state.edit_venue_id = int(venue_id)
            st.session_state.current_page = "Edit Venue"
        
        query = """
            SELECT v.venue_id, v.name, vt.name as venue_type, v.city, 
                   v.max_capacity, v.base_price, v.description,
                   COUNT(DISTINCT b.booking_id) as total_bookings,
                   COALESCE(AVG(r.rating), 0) as avg_rating,
                   ph.url as photo_url
            FROM Venue v
            JOIN VenueType vt ON v.venue_type_id = vt.venue_type_id
            LEFT JOIN Booking b ON v.venue_id = b.venue_id
            LEFT JOIN Review r ON v.venue_id = r.venue_id
            LEFT JOIN Photo ph ON v.venue_id = ph.venue_id AND ph.is_primary = TRUE
            WHERE v.owner_id = %s
            GROUP BY v.venue_id, v.name, vt.name, v.city, v.max_capacity, v.base_price, v.description, ph.url
            ORDER BY v.name
        """
        df = execute_query(query, (st.session_state.user['user_id'],))
        
        if df is not None and not df.empty:
            # Display as cards (2 per row)
            for i in range(0, len(df), 2):
                cols = st.columns(2)
                for j, col in enumerate(cols):
                    if i + j < len(df):
                        venue = df.iloc[i + j]
                        with col:
                            # Get photo URL
                            photo_url = None
                            if pd.notna(venue['photo_url']):
                                photo_url = venue['photo_url']
                                if photo_url.startswith('venue_photos/') and not os.path.exists(photo_url):
                                    photo_url = None
                            
                            if not photo_url:
                                photo_url = 'https://images.unsplash.com/photo-1519167758481-83f29da8a1c4'
                            
                            st.markdown(f"""
                            <div style='background-color: #1a1a1a; border-radius: 10px; overflow: hidden; margin-bottom: 20px; border: 1px solid #2a2a2a;'>
                            """, unsafe_allow_html=True)
                            
                            # Display image
                            if photo_url.startswith('venue_photos/'):
                                st.image(photo_url, use_container_width=True)
                            else:
                                st.image(photo_url, use_container_width=True)
                            
                            # Info section
                            st.markdown(f"""
                            <div style='padding: 20px;'>
                                <div style='display: flex; justify-content: space-between; align-items: start;'>
                                    <div>
                                        <h3 style='margin: 0 0 8px 0;'>{venue['name']}</h3>
                                        <p style='color: rgba(255,255,255,0.6); margin: 4px 0;'>ðŸ“ {venue['city']} - {venue['venue_type']}</p>
                                    </div>
                                    <div style='background: rgba(255,215,0,0.15); padding: 4px 12px; border-radius: 20px;'>
                                        <span style='color: #ffd700;'>â­ {venue['avg_rating']:.1f}</span>
                                    </div>
                                </div>
                                <p style='color: rgba(255,255,255,0.8); margin: 12px 0;'>{venue['description'][:100] if pd.notna(venue['description']) else 'No description'}...</p>
                                <p style='color: rgba(255,255,255,0.6); margin: 8px 0;'>ðŸ‘¥ Up to {venue['max_capacity']} guests</p>
                                <p style='color: rgba(255,255,255,0.6); margin: 8px 0;'>ðŸ“… {venue['total_bookings']} bookings</p>
                                <p style='font-size: 1.4em; color: white; font-weight: 600; margin: 12px 0;'>${float(venue['base_price']):,.0f}</p>
                            </div>
                            </div>
                            """, unsafe_allow_html=True)
                            
                            # View Details button
                            button_key = f"my_venue_details_{venue['venue_id']}_{i}_{j}"
                            st.button("Manage Venue", key=button_key, use_container_width=True, 
                                     on_click=lambda v_id=venue['venue_id']: navigate_to_edit_venue(v_id))
            
            st.markdown("---")
            st.subheader("Venue Portfolio Summary")
            summary_col1, summary_col2, summary_col3 = st.columns(3)
            with summary_col1:
                st.metric("Total Venues", len(df))
            with summary_col2:
                total_bookings = df['total_bookings'].sum()
                st.metric("Total Bookings", int(total_bookings))
            with summary_col3:
                avg_rating = df['avg_rating'].mean()
                st.metric("Avg Rating", f"{avg_rating:.1f} â­")
        else:
            st.info("You don't have any venues yet. Add your first venue!")
    
    # ADD NEW VENUE (Venue Owner)
    elif page == "Add New Venue":
        st.header("âž• Add New Venue")
        
        with st.form("add_venue_form"):
            col1, col2 = st.columns(2)
            
            with col1:
                venue_name = st.text_input("Venue Name*")
                
                types_query = "SELECT venue_type_id, name FROM VenueType ORDER BY name"
                types_df = execute_query(types_query)
                if types_df is not None and not types_df.empty:
                    type_options = {row['name']: int(row['venue_type_id']) for _, row in types_df.iterrows()}
                    selected_type = st.selectbox("Venue Type*", list(type_options.keys()))
                    venue_type_id = type_options[selected_type]
                
                city = st.text_input("City*")
                address = st.text_area("Address*")
            
            with col2:
                max_capacity = st.number_input("Maximum Capacity*", min_value=1, value=100)
                base_price = st.number_input("Base Price ($)*", min_value=0.0, value=50000.0, step=1000.0)
                description = st.text_area("Description")
            
            st.subheader("Add Packages")
            num_packages = st.number_input("Number of packages to add", min_value=1, max_value=5, value=1)
            
            packages = []
            for i in range(int(num_packages)):
                st.write(f"**Package {i+1}**")
                col_a, col_b, col_c = st.columns(3)
                with col_a:
                    pkg_name = st.text_input(f"Package Name", key=f"pkg_name_{i}")
                with col_b:
                    pkg_price = st.number_input(f"Price ($)", min_value=0.0, value=1000.0, key=f"pkg_price_{i}")
                with col_c:
                    pkg_per_plate = st.checkbox(f"Per Plate?", key=f"pkg_per_plate_{i}")
                
                pkg_desc = st.text_input(f"Description", key=f"pkg_desc_{i}")
                packages.append({
                    'name': pkg_name,
                    'price': pkg_price,
                    'per_plate': pkg_per_plate,
                    'description': pkg_desc
                })
            
            st.subheader("Add Photos")
            st.write("Upload photos from your computer or use URLs")
            
            photo_method = st.radio("Choose photo upload method:", ["Upload from Computer", "Use Photo URLs"])
            
            uploaded_photos = []
            photo_urls = []
            
            if photo_method == "Upload from Computer":
                st.info("ðŸ“¸ Upload 1-5 photos (JPG, PNG, JPEG)")
                uploaded_files = st.file_uploader("Choose photos", type=['jpg', 'jpeg', 'png'], 
                                                 accept_multiple_files=True, key="venue_photos")
                
                if uploaded_files and len(uploaded_files) > 5:
                    st.warning("Maximum 5 photos allowed. Only first 5 will be used.")
                    uploaded_files = uploaded_files[:5]
                
                for i, file in enumerate(uploaded_files or []):
                    col_p1, col_p2 = st.columns([3, 1])
                    with col_p1:
                        st.write(f"ðŸ“· {file.name}")
                    with col_p2:
                        is_primary = st.checkbox(f"Primary", key=f"up_primary_{i}", value=(i==0))
                    caption = st.text_input(f"Caption", key=f"up_caption_{i}", value=f"Photo {i+1}")
                    
                    uploaded_photos.append({
                        'file': file,
                        'caption': caption,
                        'is_primary': is_primary
                    })
            
            else:
                num_photos = st.number_input("Number of photos to add", min_value=1, max_value=5, value=2)
                
                for i in range(int(num_photos)):
                    st.write(f"**Photo {i+1}**")
                    col_p1, col_p2 = st.columns([3, 1])
                    with col_p1:
                        photo_url = st.text_input(f"Photo URL", 
                            placeholder="https://images.unsplash.com/photo-...", 
                            key=f"photo_url_{i}")
                    with col_p2:
                        is_primary = st.checkbox(f"Primary", key=f"photo_primary_{i}", value=(i==0))
                    
                    photo_caption = st.text_input(f"Caption", key=f"photo_caption_{i}", value=f"Venue View {i+1}")
                    
                    if photo_url:
                        photo_urls.append({
                            'url': photo_url,
                            'caption': photo_caption,
                            'is_primary': is_primary
                        })
            
            submitted = st.form_submit_button("âž• Add Venue", use_container_width=True)
            
            if submitted:
                if not all([venue_name, city, address]):
                    st.error("Please fill in all required fields marked with *")
                else:
                    venue_query = """
                        INSERT INTO Venue (owner_id, name, venue_type_id, city, address, 
                                         max_capacity, base_price, description)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                        RETURNING venue_id
                    """
                    conn = get_connection()
                    if conn:
                        try:
                            cur = conn.cursor()
                            cur.execute(venue_query, (
                                int(st.session_state.user['user_id']), 
                                venue_name, 
                                int(venue_type_id),
                                city, 
                                address, 
                                int(max_capacity), 
                                float(base_price), 
                                description
                            ))
                            venue_id = int(cur.fetchone()[0])
                            
                            for pkg in packages:
                                if pkg['name']:
                                    pkg_query = """
                                        INSERT INTO Package (venue_id, name, price, price_per_plate, 
                                                           max_capacity, description)
                                        VALUES (%s, %s, %s, %s, %s, %s)
                                    """
                                    cur.execute(pkg_query, (
                                        int(venue_id), 
                                        pkg['name'], 
                                        float(pkg['price']), 
                                        bool(pkg['per_plate']),
                                        int(max_capacity), 
                                        pkg['description']
                                    ))
                            
                            photos_added = False
                            
                            if uploaded_photos:
                                for photo in uploaded_photos:
                                    file_path = save_uploaded_file(photo['file'], venue_id)
                                    if file_path:
                                        photo_query = """
                                            INSERT INTO Photo (venue_id, url, caption, is_primary)
                                            VALUES (%s, %s, %s, %s)
                                        """
                                        cur.execute(photo_query, (
                                            int(venue_id), 
                                            file_path,
                                            photo['caption'],
                                            bool(photo['is_primary'])
                                        ))
                                        photos_added = True
                            
                            if photo_urls:
                                for photo in photo_urls:
                                    photo_query = """
                                        INSERT INTO Photo (venue_id, url, caption, is_primary)
                                        VALUES (%s, %s, %s, %s)
                                    """
                                    cur.execute(photo_query, (
                                        int(venue_id), 
                                        photo['url'],
                                        photo['caption'],
                                        bool(photo['is_primary'])
                                    ))
                                    photos_added = True
                            
                            if not photos_added:
                                photo_query = """
                                    INSERT INTO Photo (venue_id, url, caption, is_primary)
                                    VALUES (%s, %s, %s, %s)
                                """
                                cur.execute(photo_query, (
                                    int(venue_id), 
                                    'https://images.unsplash.com/photo-1519167758481-83f29da8a1c4',
                                    'Main View',
                                    True
                                ))
                            
                            conn.commit()
                            conn.close()
                            st.success("âœ… Venue added successfully!")
                            st.balloons()
                        except Exception as e:
                            st.error(f"Error adding venue: {e}")
                            conn.close()
    
    # EDIT VENUE (Venue Owner)
    elif page == "Edit Venue":
        st.header("Edit Venue")
        
        # Get venue to edit from session state or let user select
        venue_id = st.session_state.get('edit_venue_id', None)
        
        # Get owner's venues
        venues_query = """
            SELECT v.venue_id, v.name, v.city 
            FROM Venue v 
            WHERE v.owner_id = %s 
            ORDER BY v.name
        """
        venues_df = execute_query(venues_query, (st.session_state.user['user_id'],))
        
        if venues_df is not None and not venues_df.empty:
            venue_options = {f"{row['name']} - {row['city']}": int(row['venue_id']) 
                           for _, row in venues_df.iterrows()}
            
            # Find default index if venue was pre-selected
            default_index = 0
            if venue_id:
                for idx, (key, vid) in enumerate(venue_options.items()):
                    if vid == venue_id:
                        default_index = idx
                        break
            
            selected_venue = st.selectbox("Select Venue to Edit", list(venue_options.keys()), index=default_index)
            venue_id = venue_options[selected_venue]
            
            # Clear the session state after using
            if 'edit_venue_id' in st.session_state:
                del st.session_state.edit_venue_id
            
            # Get current venue details
            venue_query = """
                SELECT v.*, vt.name as venue_type_name
                FROM Venue v
                JOIN VenueType vt ON v.venue_type_id = vt.venue_type_id
                WHERE v.venue_id = %s AND v.owner_id = %s
            """
            venue_df = execute_query(venue_query, (venue_id, st.session_state.user['user_id']))
            
            if venue_df is not None and not venue_df.empty:
                venue = venue_df.iloc[0]
                
                st.markdown("---")
                
                tab1, tab2, tab3 = st.tabs(["Basic Info", "Packages", "Photos"])
                
                with tab1:
                    with st.form("edit_venue_form"):
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            venue_name = st.text_input("Venue Name*", value=venue['name'])
                            
                            types_query = "SELECT venue_type_id, name FROM VenueType ORDER BY name"
                            types_df = execute_query(types_query)
                            if types_df is not None and not types_df.empty:
                                type_options = {row['name']: int(row['venue_type_id']) for _, row in types_df.iterrows()}
                                type_names = list(type_options.keys())
                                default_type_idx = type_names.index(venue['venue_type_name']) if venue['venue_type_name'] in type_names else 0
                                selected_type = st.selectbox("Venue Type*", type_names, index=default_type_idx)
                                venue_type_id = type_options[selected_type]
                            
                            city = st.text_input("City*", value=venue['city'] or '')
                            address = st.text_area("Address*", value=venue['address'] or '')
                        
                        with col2:
                            max_capacity = st.number_input("Maximum Capacity*", min_value=1, value=int(venue['max_capacity'] or 100))
                            base_price = st.number_input("Base Price ($)*", min_value=0.0, value=float(venue['base_price'] or 0), step=1000.0)
                            description = st.text_area("Description", value=venue['description'] or '')
                        
                        submitted = st.form_submit_button("Save Changes", use_container_width=True)
                        
                        if submitted:
                            if not all([venue_name, city, address]):
                                st.error("Please fill in all required fields marked with *")
                            else:
                                update_query = """
                                    UPDATE Venue 
                                    SET name = %s, venue_type_id = %s, city = %s, address = %s,
                                        max_capacity = %s, base_price = %s, description = %s
                                    WHERE venue_id = %s AND owner_id = %s
                                """
                                result = execute_query(update_query, (
                                    venue_name, venue_type_id, city, address,
                                    max_capacity, base_price, description,
                                    venue_id, st.session_state.user['user_id']
                                ), fetch=False)
                                
                                if result:
                                    st.success("Venue updated successfully!")
                                    st.rerun()
                                else:
                                    st.error("Failed to update venue")
                
                with tab2:
                    st.subheader("Manage Packages")
                    
                    # Show existing packages
                    packages_query = """
                        SELECT package_id, name, price, price_per_plate, max_capacity, description
                        FROM Package
                        WHERE venue_id = %s
                        ORDER BY name
                    """
                    packages_df = execute_query(packages_query, (venue_id,))
                    
                    if packages_df is not None and not packages_df.empty:
                        st.write("**Existing Packages:**")
                        for _, pkg in packages_df.iterrows():
                            col1, col2, col3 = st.columns([3, 1, 1])
                            with col1:
                                price_type = "per plate" if pkg['price_per_plate'] else "fixed"
                                st.write(f"**{pkg['name']}** - ${float(pkg['price']):,.0f} ({price_type})")
                                if pkg['description']:
                                    st.caption(pkg['description'])
                            with col2:
                                st.write(f"Cap: {pkg['max_capacity']}")
                            with col3:
                                if st.button("Delete", key=f"del_pkg_{pkg['package_id']}"):
                                    delete_query = "DELETE FROM Package WHERE package_id = %s AND venue_id = %s"
                                    execute_query(delete_query, (pkg['package_id'], venue_id), fetch=False)
                                    st.success("Package deleted!")
                                    st.rerun()
                        st.markdown("---")
                    
                    # Add new package
                    st.write("**Add New Package:**")
                    with st.form("add_package_form"):
                        col_a, col_b = st.columns(2)
                        with col_a:
                            new_pkg_name = st.text_input("Package Name")
                            new_pkg_price = st.number_input("Price ($)", min_value=0.0, value=1000.0, step=100.0)
                        with col_b:
                            new_pkg_per_plate = st.checkbox("Price is per plate")
                            new_pkg_capacity = st.number_input("Max Capacity", min_value=1, value=int(venue['max_capacity'] or 100))
                        new_pkg_desc = st.text_input("Description")
                        
                        if st.form_submit_button("Add Package"):
                            if new_pkg_name:
                                insert_pkg_query = """
                                    INSERT INTO Package (venue_id, name, price, price_per_plate, max_capacity, description)
                                    VALUES (%s, %s, %s, %s, %s, %s)
                                """
                                result = execute_query(insert_pkg_query, (
                                    venue_id, new_pkg_name, new_pkg_price, new_pkg_per_plate,
                                    new_pkg_capacity, new_pkg_desc
                                ), fetch=False)
                                if result:
                                    st.success("Package added!")
                                    st.rerun()
                            else:
                                st.warning("Please enter a package name")
                
                with tab3:
                    st.subheader("Manage Photos")
                    
                    # Show existing photos
                    photos_query = """
                        SELECT photo_id, url, caption, is_primary
                        FROM Photo
                        WHERE venue_id = %s
                        ORDER BY is_primary DESC, photo_id
                    """
                    photos_df = execute_query(photos_query, (venue_id,))
                    
                    if photos_df is not None and not photos_df.empty:
                        st.write("**Existing Photos:**")
                        photo_cols = st.columns(3)
                        for idx, photo in photos_df.iterrows():
                            with photo_cols[idx % 3]:
                                photo_url = photo['url']
                                if photo_url.startswith('venue_photos/') and not os.path.exists(photo_url):
                                    st.write("Image file not found")
                                else:
                                    st.image(photo_url, caption=photo['caption'] or 'No caption', use_container_width=True)
                                
                                if photo['is_primary']:
                                    st.caption("âœ… Primary Photo")
                                
                                btn_col1, btn_col2 = st.columns(2)
                                with btn_col1:
                                    if not photo['is_primary']:
                                        if st.button("Set Primary", key=f"primary_{photo['photo_id']}"):
                                            execute_query("UPDATE Photo SET is_primary = FALSE WHERE venue_id = %s", (venue_id,), fetch=False)
                                            execute_query("UPDATE Photo SET is_primary = TRUE WHERE photo_id = %s", (photo['photo_id'],), fetch=False)
                                            st.rerun()
                                with btn_col2:
                                    if st.button("Delete", key=f"del_photo_{photo['photo_id']}"):
                                        execute_query("DELETE FROM Photo WHERE photo_id = %s", (photo['photo_id'],), fetch=False)
                                        st.success("Photo deleted!")
                                        st.rerun()
                        st.markdown("---")
                    
                    # Add new photo
                    st.write("**Add New Photo:**")
                    photo_method = st.radio("Upload method:", ["URL", "Upload File"], key="photo_method_edit")
                    
                    if photo_method == "URL":
                        with st.form("add_photo_url_form"):
                            new_photo_url = st.text_input("Photo URL", placeholder="https://images.unsplash.com/...")
                            new_photo_caption = st.text_input("Caption")
                            new_photo_primary = st.checkbox("Set as primary photo")
                            
                            if st.form_submit_button("Add Photo"):
                                if new_photo_url:
                                    if new_photo_primary:
                                        execute_query("UPDATE Photo SET is_primary = FALSE WHERE venue_id = %s", (venue_id,), fetch=False)
                                    
                                    insert_photo_query = """
                                        INSERT INTO Photo (venue_id, url, caption, is_primary)
                                        VALUES (%s, %s, %s, %s)
                                    """
                                    result = execute_query(insert_photo_query, (
                                        venue_id, new_photo_url, new_photo_caption, new_photo_primary
                                    ), fetch=False)
                                    if result:
                                        st.success("Photo added!")
                                        st.rerun()
                                else:
                                    st.warning("Please enter a photo URL")
                    else:
                        uploaded_file = st.file_uploader("Choose photo", type=['jpg', 'jpeg', 'png'])
                        new_photo_caption = st.text_input("Caption", key="upload_caption")
                        new_photo_primary = st.checkbox("Set as primary photo", key="upload_primary")
                        
                        if st.button("Upload Photo"):
                            if uploaded_file:
                                file_path = save_uploaded_file(uploaded_file, venue_id)
                                if file_path:
                                    if new_photo_primary:
                                        execute_query("UPDATE Photo SET is_primary = FALSE WHERE venue_id = %s", (venue_id,), fetch=False)
                                    
                                    insert_photo_query = """
                                        INSERT INTO Photo (venue_id, url, caption, is_primary)
                                        VALUES (%s, %s, %s, %s)
                                    """
                                    result = execute_query(insert_photo_query, (
                                        venue_id, file_path, new_photo_caption, new_photo_primary
                                    ), fetch=False)
                                    if result:
                                        st.success("Photo uploaded!")
                                        st.rerun()
                            else:
                                st.warning("Please select a file to upload")
                
                # Danger zone - Delete venue
                st.markdown("---")
                with st.expander("âš ï¸ Danger Zone"):
                    st.warning("Deleting a venue will also delete all its packages, photos, bookings, and reviews. This action cannot be undone!")
                    
                    confirm_name = st.text_input("Type the venue name to confirm deletion:", key="confirm_delete")
                    
                    if st.button("Delete Venue", type="primary"):
                        if confirm_name == venue['name']:
                            delete_query = "DELETE FROM Venue WHERE venue_id = %s AND owner_id = %s"
                            result = execute_query(delete_query, (venue_id, st.session_state.user['user_id']), fetch=False)
                            if result:
                                st.success("Venue deleted successfully!")
                                st.session_state.current_page = "My Venues"
                                st.rerun()
                        else:
                            st.error("Venue name doesn't match. Please type the exact venue name to confirm.")
            else:
                st.error("Venue not found or you don't have permission to edit it")
        else:
            st.info("You don't have any venues to edit. Add a venue first!")
            if st.button("Add New Venue"):
                st.session_state.current_page = "Add New Venue"
                st.rerun()
    
    # VENUE BOOKINGS (Venue Owner)
    elif page == "Venue Bookings":
        st.header("Venue Bookings")
        
        query = """
            SELECT b.booking_id, v.name as venue, v.city, u.name as organizer,
                   u.email as organizer_email, u.phone as organizer_phone,
                   b.booking_date, b.timeslot, b.guests_count, 
                   b.total_price, b.status, p.name as package_name,
                   ph.url as photo_url
            FROM Booking b
            JOIN Venue v ON b.venue_id = v.venue_id
            JOIN "User" u ON b.organizer_id = u.user_id
            LEFT JOIN Package p ON b.package_id = p.package_id
            LEFT JOIN Photo ph ON v.venue_id = ph.venue_id AND ph.is_primary = TRUE
            WHERE v.owner_id = %s
            ORDER BY b.booking_date DESC
        """
        df = execute_query(query, (st.session_state.user['user_id'],))
        
        if df is not None and not df.empty:
            # Filter options
            col1, col2 = st.columns(2)
            with col1:
                status_filter = st.selectbox("Filter by Status", ["All", "PENDING", "CONFIRMED", "COMPLETED", "CANCELLED"])
            with col2:
                venue_filter = st.selectbox("Filter by Venue", ["All"] + df['venue'].unique().tolist())
            
            # Apply filters
            filtered_df = df.copy()
            if status_filter != "All":
                filtered_df = filtered_df[filtered_df['status'] == status_filter]
            if venue_filter != "All":
                filtered_df = filtered_df[filtered_df['venue'] == venue_filter]
            
            if not filtered_df.empty:
                st.write(f"Showing {len(filtered_df)} bookings")
                
                # Display as cards (2 per row)
                for i in range(0, len(filtered_df), 2):
                    cols = st.columns(2)
                    for j, col in enumerate(cols):
                        if i + j < len(filtered_df):
                            booking = filtered_df.iloc[i + j]
                            with col:
                                # Get photo URL
                                photo_url = None
                                if pd.notna(booking['photo_url']):
                                    photo_url = booking['photo_url']
                                    if photo_url.startswith('venue_photos/') and not os.path.exists(photo_url):
                                        photo_url = None
                                
                                if not photo_url:
                                    photo_url = 'https://images.unsplash.com/photo-1519167758481-83f29da8a1c4'
                                
                                # Status color
                                status_colors = {
                                    'PENDING': '#ffa500',
                                    'CONFIRMED': '#00d4ff',
                                    'COMPLETED': '#28a745',
                                    'CANCELLED': '#dc3545'
                                }
                                status_color = status_colors.get(booking['status'], '#ffffff')
                                
                                # Format values
                                price_value = float(booking['total_price']) if booking['total_price'] else 0
                                price_str = f"${price_value:,.0f}"
                                org_phone = booking['organizer_phone'] if pd.notna(booking['organizer_phone']) else 'N/A'
                                
                                # Display image
                                st.image(photo_url, use_container_width=True)
                                
                                # Extract values to avoid f-string nesting issues
                                venue_name = str(booking['venue'])
                                city_name = str(booking['city'])
                                status = str(booking['status'])
                                booking_date = str(booking['booking_date'])
                                timeslot_title = str(booking['timeslot']).title()
                                guests = str(booking['guests_count'])
                                organizer_name = str(booking['organizer'])
                                organizer_email = str(booking['organizer_email'])
                                
                                # Build HTML
                                html_content = "<div style='background-color: #1a1a1a; padding: 20px; border-radius: 0 0 10px 10px; margin-top: -10px; border: 1px solid #2a2a2a;'>"
                                html_content += "<div style='display: flex; justify-content: space-between; align-items: start;'>"
                                html_content += "<div>"
                                html_content += f"<h3 style='margin: 0 0 8px 0; color: white;'>{venue_name}</h3>"
                                html_content += f"<p style='color: rgba(255,255,255,0.6); margin: 4px 0;'>{city_name}</p>"
                                html_content += "</div>"
                                html_content += f"<div style='background: rgba(255,255,255,0.1); padding: 6px 14px; border-radius: 20px; border: 2px solid {status_color};'>"
                                html_content += f"<span style='color: {status_color}; font-weight: 600;'>{status}</span>"
                                html_content += "</div></div>"
                                html_content += f"<p style='color: rgba(255,255,255,0.6); margin: 12px 0;'>{booking_date} - {timeslot_title}</p>"
                                html_content += f"<p style='color: rgba(255,255,255,0.6); margin: 8px 0;'>{guests} guests</p>"
                                
                                # Add package if exists
                                if pd.notna(booking['package_name']):
                                    pkg_name = str(booking['package_name'])
                                    html_content += f"<p style='color: rgba(255,255,255,0.6); margin: 8px 0;'>Package: {pkg_name}</p>"
                                
                                # Add organizer section
                                html_content += "<div style='background: rgba(255,255,255,0.05); padding: 12px; border-radius: 8px; margin: 12px 0;'>"
                                html_content += f"<p style='color: rgba(255,255,255,0.8); margin: 0 0 4px 0;'><strong>Organizer:</strong> {organizer_name}</p>"
                                html_content += f"<p style='color: rgba(255,255,255,0.6); margin: 0 0 4px 0;'>Email: {organizer_email}</p>"
                                html_content += f"<p style='color: rgba(255,255,255,0.6); margin: 0;'>Phone: {org_phone}</p>"
                                html_content += "</div>"
                                html_content += f"<p style='font-size: 1.4em; color: white; font-weight: 600; margin: 12px 0;'>{price_str}</p>"
                                html_content += "</div>"
                                
                                st.markdown(html_content, unsafe_allow_html=True)
                
                # Summary section
                st.markdown("---")
                st.subheader("Booking Summary")
                summary_col1, summary_col2, summary_col3, summary_col4 = st.columns(4)
                with summary_col1:
                    st.metric("Total Bookings", len(df))
                with summary_col2:
                    pending = len(df[df['status'] == 'PENDING'])
                    st.metric("Pending", pending)
                with summary_col3:
                    confirmed = len(df[df['status'] == 'CONFIRMED'])
                    st.metric("Confirmed", confirmed)
                with summary_col4:
                    total_revenue = float(df[df['status'].isin(['CONFIRMED', 'COMPLETED'])]['total_price'].sum())
                    st.metric("Total Revenue", f"${total_revenue:,.0f}")
            else:
                st.info("No bookings match the selected filters")
        else:
            st.info("No bookings yet for your venues")
    
    # REVENUE ANALYTICS (Venue Owner)
    elif page == "Revenue Analytics":
        st.header("ðŸ’° Revenue Analytics")
        
        st.subheader("Revenue by Venue")
        query = """
            SELECT v.name, COUNT(b.booking_id) as total_bookings,
                   SUM(b.total_price) as total_revenue,
                   AVG(b.guests_count) as avg_guests
            FROM Venue v
            JOIN Booking b ON v.venue_id = b.venue_id
            WHERE v.owner_id = %s AND b.status IN ('CONFIRMED', 'COMPLETED')
            GROUP BY v.venue_id, v.name
            ORDER BY total_revenue DESC
        """
        df = execute_query(query, (st.session_state.user['user_id'],))
        if df is not None and not df.empty:
            st.dataframe(df, use_container_width=True)
            st.bar_chart(df.set_index('name')['total_revenue'])
        else:
            st.info("No revenue data available yet")
    
    # BROWSE VENDORS
    elif page == "Browse Vendors":
        st.header("ðŸ› ï¸ Browse Service Vendors")
        
        vendor_type = st.selectbox("Vendor Type", ["All", "Caterer", "Decorator", "Photographer", "AV Team"])
        min_rating = st.slider("Minimum Rating", 0.0, 5.0, 0.0, 0.1)
        
        query = """
            SELECT v.vendor_id, v.company_name, v.vendor_type, v.contact_info, v.rating,
                   COUNT(bv.booking_id) as total_bookings,
                   COALESCE(SUM(bv.price_at_booking), 0) as total_revenue
            FROM Vendor v
            LEFT JOIN BookingVendor bv ON v.vendor_id = bv.vendor_id
            WHERE (%s = 'All' OR v.vendor_type = %s)
                AND v.rating >= %s
            GROUP BY v.vendor_id, v.company_name, v.vendor_type, v.contact_info, v.rating
            ORDER BY v.rating DESC, total_bookings DESC
        """
        df = execute_query(query, (vendor_type, vendor_type, min_rating))
        
        if df is not None and not df.empty:
            st.dataframe(df, use_container_width=True)
        else:
            st.info("No vendors found matching your criteria")
    
    # ADD REVIEW (Organizer)
    elif page == "Add Review":
        st.header("â­ Add Review")
        
        completed_bookings_query = """
            SELECT DISTINCT v.venue_id, v.name, v.city
            FROM Venue v
            JOIN Booking b ON v.venue_id = b.venue_id
            WHERE b.organizer_id = %s AND b.status = 'COMPLETED'
            ORDER BY v.name
        """
        venues_df = execute_query(completed_bookings_query, (st.session_state.user['user_id'],))
        
        if venues_df is not None and not venues_df.empty:
            with st.form("review_form"):
                venue_options = {f"{row['name']} - {row['city']}": int(row['venue_id']) 
                               for _, row in venues_df.iterrows()}
                selected_venue = st.selectbox("Select Venue", list(venue_options.keys()))
                venue_id = venue_options[selected_venue]
                
                check_query = """
                    SELECT review_id FROM Review 
                    WHERE venue_id = %s AND organizer_id = %s
                """
                existing = execute_query(check_query, (venue_id, st.session_state.user['user_id']))
                
                if existing is not None and not existing.empty:
                    st.warning("You have already reviewed this venue. You can only review a venue once.")
                    submitted = st.form_submit_button("Submit Review", disabled=True)
                else:
                    rating = st.select_slider("Rating", options=[1, 2, 3, 4, 5], value=5)
                    st.write("â­" * rating)
                    comment = st.text_area("Your Review", placeholder="Share your experience with this venue...")
                    
                    submitted = st.form_submit_button("Submit Review")
                    
                    if submitted:
                        if comment.strip():
                            insert_query = """
                                INSERT INTO Review (venue_id, organizer_id, rating, comment)
                                VALUES (%s, %s, %s, %s)
                            """
                            result = execute_query(insert_query, 
                                                 (venue_id, st.session_state.user['user_id'], rating, comment), 
                                                 fetch=False)
                            if result:
                                st.success("âœ… Review submitted successfully!")
                                st.balloons()
                            else:
                                st.error("Failed to submit review")
                        else:
                            st.warning("Please write a comment for your review")
        else:
            st.info("You need to complete at least one booking before you can leave a review. Complete a booking first!")
    
    # Footer
    st.markdown("---")
    st.markdown("**SoirÃ©e** - Connecting organizers with perfect venues Â© 2025")