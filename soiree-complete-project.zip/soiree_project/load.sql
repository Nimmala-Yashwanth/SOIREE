-- Load data for Soiree application

-- Insert VenueTypes
INSERT INTO VenueType (name) VALUES 
('Banquet Hall'),
('Garden'),
('Resort'),
('Party Hall'),
('Destination Venue'),
('Mandapam');

-- Insert Users (mix of organizers, venue owners, vendors)
INSERT INTO "User" (name, email, phone, password_hash, role) VALUES
('Rajesh Kumar', 'rajesh.k@email.com', '9876543210', 'hash1', 'venue_owner'),
('Priya Sharma', 'priya.s@email.com', '9876543211', 'hash2', 'venue_owner'),
('Amit Patel', 'amit.p@email.com', '9876543212', 'hash3', 'venue_owner'),
('Sneha Reddy', 'sneha.r@email.com', '9876543213', 'hash4', 'organizer'),
('Vikram Singh', 'vikram.s@email.com', '9876543214', 'hash5', 'organizer'),
('Deepa Nair', 'deepa.n@email.com', '9876543215', 'hash6', 'organizer'),
('Anita Desai', 'anita.d@email.com', '9876543216', 'hash7', 'organizer'),
('Rahul Mehta', 'rahul.m@email.com', '9876543217', 'hash8', 'organizer'),
('Kavita Iyer', 'kavita.i@email.com', '9876543218', 'hash9', 'vendor'),
('Suresh Gupta', 'suresh.g@email.com', '9876543219', 'hash10', 'vendor'),
('Meera Joshi', 'meera.j@email.com', '9876543220', 'hash11', 'venue_owner'),
('Arjun Rao', 'arjun.r@email.com', '9876543221', 'hash12', 'organizer'),
('Pooja Verma', 'pooja.v@email.com', '9876543222', 'hash13', 'organizer'),
('Kiran Kumar', 'kiran.k@email.com', '9876543223', 'hash14', 'venue_owner'),
('Lakshmi Menon', 'lakshmi.m@email.com', '9876543224', 'hash15', 'organizer'),
('Sanjay Pillai', 'sanjay.p@email.com', '9876543225', 'hash16', 'vendor'),
('Nisha Kapoor', 'nisha.k@email.com', '9876543226', 'hash17', 'organizer'),
('Manish Agarwal', 'manish.a@email.com', '9876543227', 'hash18', 'venue_owner'),
('Divya Bhat', 'divya.b@email.com', '9876543228', 'hash19', 'organizer'),
('Ravi Chandra', 'ravi.c@email.com', '9876543229', 'hash20', 'vendor');

-- Insert Venues
INSERT INTO Venue (owner_id, name, venue_type_id, city, address, max_capacity, base_price, description) VALUES
(1, 'Grand Palace Banquet', 1, 'Hyderabad', 'Jubilee Hills, Road No 36', 500, 150000.00, 'Luxurious banquet hall with modern amenities'),
(1, 'Royal Garden Resort', 3, 'Hyderabad', 'Gachibowli, Near DLF', 300, 200000.00, 'Beautiful outdoor garden with indoor facilities'),
(2, 'Crystal Events Hall', 4, 'Bangalore', 'Whitefield Main Road', 400, 120000.00, 'Modern party hall with excellent lighting'),
(2, 'Green Valley Gardens', 2, 'Bangalore', 'Sarjapur Road', 250, 100000.00, 'Scenic garden venue perfect for day events'),
(3, 'Taj Convention Center', 1, 'Mumbai', 'Bandra West', 600, 250000.00, 'Premium convention center with top-tier service'),
(3, 'Sunset Beach Resort', 5, 'Mumbai', 'Juhu Beach', 200, 300000.00, 'Exclusive beachfront destination venue'),
(11, 'Marigold Mandapam', 6, 'Chennai', 'T Nagar, GN Chetty Road', 350, 80000.00, 'Traditional mandapam for weddings'),
(11, 'Lakeside Gardens', 2, 'Chennai', 'OMR, Navalur', 280, 95000.00, 'Lakeside venue with beautiful views'),
(14, 'Diamond Hall', 4, 'Delhi', 'Connaught Place', 450, 180000.00, 'Central location with elegant interiors'),
(14, 'Heritage Palace', 1, 'Delhi', 'Mehrauli', 550, 220000.00, 'Historic palace converted to event venue'),
(18, 'Paradise Resort & Spa', 3, 'Hyderabad', 'Shamirpet', 400, 175000.00, 'Full-service resort with spa facilities'),
(18, 'Emerald Gardens', 2, 'Bangalore', 'Electronic City', 300, 110000.00, 'Lush green garden venue'),
(1, 'Silver Oak Banquet', 1, 'Mumbai', 'Andheri East', 380, 140000.00, 'Modern banquet with parking'),
(2, 'Orchid Party Lounge', 4, 'Chennai', 'Anna Nagar', 220, 75000.00, 'Trendy party venue'),
(3, 'Golden Sands Resort', 5, 'Goa', 'Calangute Beach', 150, 280000.00, 'Beachfront resort destination');

-- Insert Packages
INSERT INTO Package (venue_id, name, price, price_per_plate, max_capacity, description) VALUES
(1, 'Basic Wedding Package', 1500.00, TRUE, 500, 'Includes basic decoration and seating'),
(1, 'Premium Wedding Package', 2200.00, TRUE, 500, 'Premium decoration, stage, and seating'),
(1, 'Corporate Event Package', 180000.00, FALSE, 400, 'Fixed price for corporate events'),
(2, 'Garden Wedding Package', 2000.00, TRUE, 300, 'Outdoor garden setup with catering'),
(2, 'Reception Package', 250000.00, FALSE, 300, 'Complete reception setup'),
(3, 'Birthday Party Package', 1200.00, TRUE, 400, 'Birthday celebration setup'),
(3, 'Corporate Meeting Package', 150000.00, FALSE, 200, 'Meeting room with AV equipment'),
(4, 'Day Event Package', 900.00, TRUE, 250, 'Daytime events with lunch'),
(4, 'Evening Event Package', 1100.00, TRUE, 250, 'Evening events with dinner'),
(5, 'Grand Wedding Package', 2800.00, TRUE, 600, 'Luxury wedding with all amenities'),
(5, 'Corporate Conference', 320000.00, FALSE, 500, 'Multi-day conference package'),
(6, 'Beach Wedding Package', 3500.00, TRUE, 200, 'Exclusive beach wedding setup'),
(7, 'Traditional Wedding Package', 1400.00, TRUE, 350, 'Traditional mandapam setup'),
(7, 'Reception Package', 95000.00, FALSE, 350, 'Reception with traditional decor'),
(8, 'Lakeside Wedding', 1600.00, TRUE, 280, 'Wedding by the lake'),
(9, 'Corporate Party Package', 1800.00, TRUE, 450, 'Corporate celebration'),
(10, 'Royal Wedding Package', 2500.00, TRUE, 550, 'Heritage palace wedding'),
(11, 'Spa & Wedding Combo', 2100.00, TRUE, 400, 'Wedding with spa access'),
(12, 'Garden Party Package', 1300.00, TRUE, 300, 'Outdoor party setup'),
(13, 'Business Event Package', 1700.00, TRUE, 380, 'Business events and parties'),
(14, 'Birthday Celebration', 1000.00, TRUE, 220, 'Birthday party setup'),
(15, 'Destination Wedding', 4000.00, TRUE, 150, 'All-inclusive beach wedding');

-- Insert Photos
INSERT INTO Photo (venue_id, url, caption, is_primary) VALUES
(1, 'https://images.unsplash.com/photo-1519167758481-83f29da8a1c4', 'Main Hall View', TRUE),
(1, 'https://images.unsplash.com/photo-1464366400600-7168b8af9bc3', 'Decorated Stage', FALSE),
(1, 'https://images.unsplash.com/photo-1478146896981-b80fe463b330', 'Dining Area', FALSE),
(2, 'https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3', 'Garden View', TRUE),
(2, 'https://images.unsplash.com/photo-1505373877841-8d25f7d46678', 'Night Setup', FALSE),
(3, 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30', 'Main Hall', TRUE),
(3, 'https://images.unsplash.com/photo-1511578314322-379afb476865', 'Interior View', FALSE),
(4, 'https://images.unsplash.com/photo-1464207687429-7505649dae38', 'Garden Entrance', TRUE),
(4, 'https://images.unsplash.com/photo-1519741497674-611481863552', 'Lawn Area', FALSE),
(5, 'https://images.unsplash.com/photo-1505236858219-8359eb29e329', 'Convention Hall', TRUE),
(6, 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e', 'Beach View', TRUE),
(7, 'https://images.unsplash.com/photo-1519167758481-83f29da8a1c4', 'Mandapam Interior', TRUE),
(8, 'https://images.unsplash.com/photo-1470252649378-9c29740c9fa8', 'Lake View', TRUE),
(9, 'https://images.unsplash.com/photo-1464366400600-7168b8af9bc3', 'Diamond Hall Interior', TRUE),
(10, 'https://images.unsplash.com/photo-1519741497674-611481863552', 'Palace Exterior', TRUE);

-- Insert Vendors
INSERT INTO Vendor (user_id, vendor_type, company_name, contact_info, rating) VALUES
(9, 'Caterer', 'Spice Garden Catering', 'contact@spicegarden.com, 9988776655', 4.5),
(10, 'Decorator', 'Dream Decorators', 'info@dreamdeco.com, 9988776656', 4.8),
(16, 'Photographer', 'Moments Photography', 'hello@moments.com, 9988776657', 4.7),
(20, 'AV Team', 'Sound & Vision Tech', 'tech@soundvision.com, 9988776658', 4.6),
(NULL, 'Caterer', 'Royal Feast Catering', 'contact@royalfeast.com, 9988776659', 4.4),
(NULL, 'Decorator', 'Elegant Events Decor', 'info@elegantevents.com, 9988776660', 4.9),
(NULL, 'Photographer', 'Picture Perfect Studio', 'studio@pictureperfect.com, 9988776661', 4.5),
(NULL, 'AV Team', 'ProSound Systems', 'info@prosound.com, 9988776662', 4.3),
(NULL, 'Caterer', 'Tasty Bites Catering', 'contact@tastybites.com, 9988776663', 4.6),
(NULL, 'Decorator', 'Flower Power Decor', 'hello@flowerpower.com, 9988776664', 4.7);

-- Insert Bookings
INSERT INTO Booking (venue_id, organizer_id, package_id, booking_date, timeslot, guests_count, total_price, status) VALUES
(1, 4, 1, '2025-11-15', 'evening', 450, 675000.00, 'CONFIRMED'),
(1, 5, 2, '2025-12-20', 'evening', 480, 1056000.00, 'PENDING'),
(2, 6, 4, '2025-11-25', 'afternoon', 280, 560000.00, 'CONFIRMED'),
(3, 7, 6, '2025-10-10', 'evening', 350, 420000.00, 'COMPLETED'),
(4, 8, 8, '2025-09-15', 'afternoon', 200, 180000.00, 'COMPLETED'),
(5, 12, 10, '2025-12-05', 'evening', 550, 1540000.00, 'CONFIRMED'),
(6, 13, 12, '2026-01-10', 'afternoon', 180, 630000.00, 'PENDING'),
(7, 15, 13, '2025-11-30', 'morning', 320, 448000.00, 'CONFIRMED'),
(8, 17, 15, '2025-12-15', 'evening', 250, 400000.00, 'PENDING'),
(9, 19, 16, '2025-10-20', 'evening', 400, 720000.00, 'COMPLETED'),
(10, 4, 17, '2026-02-14', 'evening', 500, 1250000.00, 'PENDING'),
(11, 5, 18, '2025-11-18', 'afternoon', 350, 735000.00, 'CONFIRMED'),
(1, 6, 3, '2025-10-05', 'morning', 300, 180000.00, 'COMPLETED'),
(2, 7, 5, '2026-01-20', 'evening', 250, 250000.00, 'PENDING'),
(3, 8, 7, '2025-11-08', 'morning', 180, 150000.00, 'CONFIRMED');

-- Insert BookingVendors
INSERT INTO BookingVendor (booking_id, vendor_id, service_description, price_at_booking) VALUES
(1, 1, 'Full catering service for 450 guests', 150000.00),
(1, 2, 'Complete venue decoration', 80000.00),
(1, 3, 'Photography and videography', 60000.00),
(2, 1, 'Catering for 480 guests', 160000.00),
(2, 4, 'Sound system and lighting', 45000.00),
(3, 5, 'Premium catering service', 120000.00),
(3, 6, 'Floral decoration', 95000.00),
(4, 7, 'Event photography', 50000.00),
(5, 8, 'Audio visual setup', 35000.00),
(6, 9, 'Catering service', 180000.00),
(6, 2, 'Grand decoration', 120000.00),
(7, 1, 'Beach wedding catering', 200000.00),
(8, 10, 'Traditional decor', 70000.00),
(9, 3, 'Professional photography', 55000.00),
(10, 4, 'Event sound system', 40000.00);

-- Insert Reviews
INSERT INTO Review (venue_id, organizer_id, rating, comment) VALUES
(1, 4, 5, 'Amazing venue! The staff was very professional and helpful.'),
(3, 7, 4, 'Great location and facilities. Would recommend for corporate events.'),
(4, 8, 5, 'Beautiful garden setting. Perfect for our family event.'),
(9, 19, 4, 'Good venue but parking could be better.'),
(1, 6, 5, 'Excellent service and beautiful interiors.'),
(2, 5, 4, 'Lovely outdoor space, great for weddings.'),
(5, 12, 5, 'Top-notch facilities and service. Worth the price.'),
(7, 15, 4, 'Traditional setup was perfect for our wedding.'),
(3, 8, 5, 'Very satisfied with the arrangements.'),
(10, 4, 5, 'The palace venue exceeded our expectations.');

-- Insert Payments
INSERT INTO Payment (booking_id, amount, method, status) VALUES
(1, 337500.00, 'Bank Transfer', 'COMPLETED'),
(1, 337500.00, 'Credit Card', 'COMPLETED'),
(2, 528000.00, 'UPI', 'PENDING'),
(3, 280000.00, 'Bank Transfer', 'COMPLETED'),
(3, 280000.00, 'Credit Card', 'COMPLETED'),
(4, 210000.00, 'Bank Transfer', 'COMPLETED'),
(4, 210000.00, 'Cash', 'COMPLETED'),
(5, 90000.00, 'UPI', 'COMPLETED'),
(5, 90000.00, 'Credit Card', 'COMPLETED'),
(6, 770000.00, 'Bank Transfer', 'COMPLETED'),
(7, 315000.00, 'UPI', 'PENDING'),
(8, 224000.00, 'Bank Transfer', 'COMPLETED'),
(8, 224000.00, 'Credit Card', 'COMPLETED'),
(9, 360000.00, 'Bank Transfer', 'COMPLETED'),
(10, 625000.00, 'UPI', 'PENDING');