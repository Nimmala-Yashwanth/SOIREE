# Contributing to Soirée

First off, thank you for considering contributing to Soirée! It's people like you that make Soirée such a great tool.

## Code of Conduct

This project and everyone participating in it is governed by our Code of Conduct. By participating, you are expected to uphold this code.

## How Can I Contribute?

### Reporting Bugs

Before creating bug reports, please check the existing issues as you might find out that you don't need to create one. When you are creating a bug report, please include as many details as possible:

* **Use a clear and descriptive title**
* **Describe the exact steps to reproduce the problem**
* **Provide specific examples**
* **Describe the behavior you observed and what behavior you expected**
* **Include screenshots if possible**
* **Include your environment details** (OS, Python version, PostgreSQL version)

### Suggesting Enhancements

Enhancement suggestions are tracked as GitHub issues. When creating an enhancement suggestion, please include:

* **Use a clear and descriptive title**
* **Provide a detailed description of the suggested enhancement**
* **Explain why this enhancement would be useful**
* **List some examples of how it would be used**

### Pull Requests

* Fill in the required template
* Follow the Python style guide (PEP 8)
* Include comments in your code where necessary
* Update documentation as needed
* Write clear commit messages

## Development Process

### Setting Up Your Development Environment

1. Fork the repo
2. Clone your fork:
   ```bash
   git clone https://github.com/yourusername/soiree.git
   ```
3. Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Set up the database (see SETUP.md)

### Making Changes

1. Create a new branch:
   ```bash
   git checkout -b feature/your-feature-name
   ```
2. Make your changes
3. Test your changes thoroughly
4. Commit your changes:
   ```bash
   git commit -m "Add feature: description of feature"
   ```
5. Push to your fork:
   ```bash
   git push origin feature/your-feature-name
   ```
6. Open a Pull Request

### Commit Message Guidelines

* Use the present tense ("Add feature" not "Added feature")
* Use the imperative mood ("Move cursor to..." not "Moves cursor to...")
* Limit the first line to 72 characters or less
* Reference issues and pull requests after the first line

Examples:
```
Add user profile page
Fix booking date validation bug
Update README with new setup instructions
```

## Style Guide

### Python Style Guide

* Follow PEP 8
* Use 4 spaces for indentation
* Maximum line length of 100 characters
* Use descriptive variable names
* Add docstrings to functions and classes

### Database Guidelines

* Use lowercase with underscores for table and column names
* Add indexes for foreign keys and frequently queried columns
* Use appropriate data types
* Add constraints where applicable

### SQL Style

* Keywords in UPPERCASE
* Table/column names in lowercase
* Indent subqueries
* One column per line in SELECT statements (for complex queries)

### Streamlit Guidelines

* Keep pages modular and focused
* Use session state appropriately
* Cache expensive operations
* Provide clear user feedback
* Maintain consistent styling

## Testing

Before submitting a pull request:

1. Test all affected functionality
2. Test with different user roles
3. Test edge cases
4. Verify database operations
5. Check for SQL injection vulnerabilities
6. Test responsive design

## Documentation

* Update README.md if you change functionality
* Update SETUP.md if you change setup process
* Add comments to complex code
* Update CHANGELOG.md
* Include docstrings for new functions

## Project Structure

```
soiree/
├── project.py          # Main application
├── schema.sql          # Database schema
├── load.sql           # Sample data
├── requirements.txt    # Dependencies
├── README.md          # Main documentation
├── SETUP.md           # Setup guide
├── CONTRIBUTING.md    # This file
└── LICENSE            # MIT License
```

## Questions?

Feel free to open an issue with your question or reach out to the maintainers.

## Recognition

Contributors will be recognized in the README.md file.

Thank you for contributing! 🎉
