# Soirée - Setup Guide

## Quick Start

This guide will help you get Soirée up and running on your local machine in under 10 minutes.

## Prerequisites Checklist

- [ ] Python 3.8 or higher installed
- [ ] PostgreSQL 12 or higher installed
- [ ] Git installed (for cloning)
- [ ] A terminal/command prompt
- [ ] A code editor (VS Code, PyCharm, etc.)

## Step-by-Step Setup

### 1. Clone or Download the Project

```bash
# If using Git
git clone https://github.com/yourusername/soiree.git
cd soiree

# Or download and extract the ZIP file
```

### 2. Set Up Python Virtual Environment (Recommended)

```bash
# Create virtual environment
python -m venv venv

# Activate it
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate
```

### 3. Install Python Dependencies

```bash
pip install -r requirements.txt
```

Expected output:
```
Successfully installed streamlit-1.28.0 psycopg2-binary-2.9.0 pandas-2.0.0
```

### 4. Set Up PostgreSQL Database

#### Option A: Using Command Line

```bash
# Create the database
createdb -U postgres soiree_dtb

# Initialize schema
psql -U postgres -d soiree_dtb -f schema.sql

# Load sample data (optional)
psql -U postgres -d soiree_dtb -f load.sql
```

#### Option B: Using pgAdmin or GUI Tool

1. Open pgAdmin
2. Create new database named `soiree_dtb`
3. Open Query Tool
4. Run the contents of `schema.sql`
5. Run the contents of `load.sql` (optional)

### 5. Configure Database Connection

Open `project.py` and find the `DB_CONFIG` section (around line 14):

```python
DB_CONFIG = {
    'dbname': 'soiree_dtb',
    'user': 'postgres',        # Change this to your PostgreSQL username
    'password': 'your_password', # Change this to your PostgreSQL password
    'host': 'localhost',
    'port': '5432'             # Change if using non-default port
}
```

Update the values to match your PostgreSQL installation.

### 6. Run the Application

```bash
streamlit run project.py
```

The application should automatically open in your browser at `http://localhost:8501`

If it doesn't open automatically, manually navigate to: `http://localhost:8501`

### 7. Create Your First Account

1. Click on the "Sign up" tab
2. Fill in your details
3. Select your role (organizer, venue_owner, or vendor)
4. Click "Sign Up"
5. Switch to "Sign in" tab and log in

## Troubleshooting

### Issue: "Connection refused" or database error

**Solution:**
1. Check PostgreSQL is running:
   ```bash
   # On macOS/Linux
   sudo service postgresql status
   
   # On Windows (check Services)
   ```
2. Verify database credentials in `project.py`
3. Ensure database `soiree_dtb` exists

### Issue: "Module not found" error

**Solution:**
```bash
# Reinstall requirements
pip install -r requirements.txt --force-reinstall
```

### Issue: Port 8501 already in use

**Solution:**
```bash
# Run on different port
streamlit run project.py --server.port 8502
```

### Issue: "Permission denied" when creating venue_photos folder

**Solution:**
```bash
# Create the folder manually
mkdir venue_photos
chmod 755 venue_photos
```

## Testing the Application

### With Sample Data

If you loaded `load.sql`, you'll have pre-populated data to explore:
- 20 users across different roles
- 15 venues in various cities
- 15 sample bookings
- 10 reviews

However, you'll need to create NEW accounts as the sample data uses hashed passwords that you don't know.

### Without Sample Data

Start by:
1. Creating a venue owner account
2. Adding a venue with packages and photos
3. Creating an organizer account
4. Searching for and booking the venue

## Configuration Options

### Change Database Port

If your PostgreSQL runs on a different port:

```python
DB_CONFIG = {
    ...
    'port': '5433'  # Your custom port
}
```

### Customize Application

Edit these sections in `project.py`:
- Lines 14-19: Database configuration
- Lines 35-47: Photo storage directory
- Lines 162-264: Custom CSS styling

## Performance Tips

1. **Add database indexes** for better search performance (already included in schema.sql)
2. **Use connection pooling** for production deployments
3. **Enable caching** in Streamlit for frequently accessed data

## Production Deployment

For production deployment:

1. Use environment variables for sensitive data:
   ```bash
   export DB_PASSWORD="your_secure_password"
   ```

2. Use a production WSGI server

3. Set up HTTPS

4. Use a managed PostgreSQL service

5. Implement proper backup strategies

## Next Steps

Once your application is running:

1. ✅ Explore the different user roles
2. ✅ Create some test venues and bookings
3. ✅ Customize the styling to match your brand
4. ✅ Add your own venue photos
5. ✅ Invite others to test the application

## Getting Help

- **GitHub Issues**: Report bugs or request features
- **Documentation**: Check README.md for detailed information
- **Database Schema**: Refer to schema.sql for data structure

## Database Schema Verification

To verify your database is set up correctly:

```sql
-- Connect to the database
\c soiree_dtb

-- List all tables
\dt

-- You should see:
-- booking, bookingvendor, package, payment, photo, review, user, venue, vendeur, venuetype

-- Check row counts
SELECT 'Users' as table, COUNT(*) FROM "User"
UNION ALL
SELECT 'Venues', COUNT(*) FROM Venue
UNION ALL
SELECT 'Bookings', COUNT(*) FROM Booking;
```

## Success Checklist

- [ ] Python dependencies installed
- [ ] PostgreSQL running
- [ ] Database created and schema loaded
- [ ] Database configuration updated in project.py
- [ ] Application starts without errors
- [ ] Can access http://localhost:8501
- [ ] Can create and login to an account
- [ ] Can navigate between pages

## Congratulations! 🎉

You're all set! Your Soirée application is now running and ready to use.

---

**Happy Event Planning! 🎊**
