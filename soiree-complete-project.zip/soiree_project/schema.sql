-- Soiree_schema.sql (PostgreSQL)
-- Drop tables in reverse dependency order
DROP TABLE IF EXISTS BookingVendor CASCADE;
DROP TABLE IF EXISTS Payment CASCADE;
DROP TABLE IF EXISTS Review CASCADE;
DROP TABLE IF EXISTS Booking CASCADE;
DROP TABLE IF EXISTS Vendor CASCADE;
DROP TABLE IF EXISTS Photo CASCADE;
DROP TABLE IF EXISTS Package CASCADE;
DROP TABLE IF EXISTS Venue CASCADE;
DROP TABLE IF EXISTS VenueType CASCADE;
DROP TABLE IF EXISTS "User" CASCADE;

-- Users: organizer, venue_owner, vendor, admin
CREATE TABLE "User" (
    user_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    email VARCHAR(200) NOT NULL UNIQUE,
    phone VARCHAR(20),
    password_hash VARCHAR(200) NOT NULL,
    role VARCHAR(20) NOT NULL CHECK (role IN ('organizer','venue_owner','vendor','admin')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE VenueType (
    venue_type_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE Venue (
    venue_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    owner_id INTEGER NOT NULL REFERENCES "User"(user_id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    venue_type_id INTEGER NOT NULL REFERENCES VenueType(venue_type_id),
    city VARCHAR(100),
    address TEXT,
    max_capacity INTEGER CHECK (max_capacity > 0),
    base_price NUMERIC(12,2) DEFAULT 0.00,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE Package (
    package_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    venue_id INTEGER NOT NULL REFERENCES Venue(venue_id) ON DELETE CASCADE,
    name VARCHAR(200) NOT NULL,
    price NUMERIC(12,2) NOT NULL CHECK (price >= 0),
    price_per_plate BOOLEAN NOT NULL DEFAULT FALSE,
    max_capacity INTEGER CHECK (max_capacity > 0),
    description TEXT
);

CREATE TABLE Photo (
    photo_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    venue_id INTEGER NOT NULL REFERENCES Venue(venue_id) ON DELETE CASCADE,
    url TEXT NOT NULL,
    caption VARCHAR(255),
    is_primary BOOLEAN DEFAULT FALSE
);

CREATE TABLE Vendor (
    vendor_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id INTEGER REFERENCES "User"(user_id) ON DELETE SET NULL,
    vendor_type VARCHAR(100),
    company_name VARCHAR(200),
    contact_info TEXT,
    rating NUMERIC(2,1) CHECK (rating >= 0 AND rating <= 5)
);

CREATE TABLE Booking (
    booking_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    venue_id INTEGER NOT NULL REFERENCES Venue(venue_id) ON DELETE CASCADE,
    organizer_id INTEGER NOT NULL REFERENCES "User"(user_id) ON DELETE CASCADE,
    package_id INTEGER REFERENCES Package(package_id) ON DELETE SET NULL,
    booking_date DATE NOT NULL,
    timeslot VARCHAR(50) NOT NULL,
    guests_count INTEGER NOT NULL CHECK (guests_count >= 0),
    total_price NUMERIC(12,2) DEFAULT 0.00,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','CONFIRMED','CANCELLED','COMPLETED')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    UNIQUE (venue_id, booking_date, timeslot)
);

CREATE TABLE BookingVendor (
    booking_id INTEGER NOT NULL REFERENCES Booking(booking_id) ON DELETE CASCADE,
    vendor_id INTEGER NOT NULL REFERENCES Vendor(vendor_id) ON DELETE CASCADE,
    service_description TEXT,
    price_at_booking NUMERIC(12,2) DEFAULT 0.00,
    PRIMARY KEY (booking_id, vendor_id)
);

CREATE TABLE Review (
    review_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    venue_id INTEGER NOT NULL REFERENCES Venue(venue_id) ON DELETE CASCADE,
    organizer_id INTEGER NOT NULL REFERENCES "User"(user_id) ON DELETE CASCADE,
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comment TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    CONSTRAINT one_review_per_user_per_venue UNIQUE (venue_id, organizer_id)
);

CREATE TABLE Payment (
    payment_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    booking_id INTEGER NOT NULL REFERENCES Booking(booking_id) ON DELETE CASCADE,
    amount NUMERIC(12,2) NOT NULL CHECK (amount >= 0),
    method VARCHAR(50),
    paid_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    status VARCHAR(20) DEFAULT 'COMPLETED' CHECK (status IN ('PENDING','COMPLETED','FAILED','REFUNDED'))
);

-- Helpful indexes for performance
CREATE INDEX idx_venue_city_type ON Venue(city, venue_type_id);
CREATE INDEX idx_booking_date ON Booking(booking_date);
CREATE INDEX idx_package_venue ON Package(venue_id);